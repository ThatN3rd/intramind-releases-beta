"""Age-based purge for IntraMind's rotating logs (TOS Section 11).

agent.log and query_errors.log rotate by size only; this adds a one-year age
bound. Pure standard library, no import of server.py. Logs counts only, never
log content.
"""
import json
import logging
import os
import re
from datetime import datetime, timedelta, timezone
from logging.handlers import RotatingFileHandler
from typing import Callable, Optional

LOG_RETENTION_DAYS = 365

_log = logging.getLogger("log_retention")

_AGENT_TS = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})(?:,\d{1,6})?(?=\s|$)")


def agent_log_dater(line: str) -> Optional[datetime]:
    """Leading 'YYYY-MM-DD HH:MM:SS[,mmm]' as UTC; None for any other line."""
    m = _AGENT_TS.match(line or "")
    if not m:
        return None
    try:
        return datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
    except Exception:
        # A timestamped line with a malformed date is treated as a continuation
        # of the line above.
        return None


def query_error_dater(line: str) -> Optional[datetime]:
    """The 'time' field (%Y-%m-%dT%H:%M:%SZ) of a JSON line as UTC; else None."""
    try:
        t = json.loads(line).get("time")
        return datetime.strptime(t, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except Exception:  # incl. RecursionError on hostile nested JSON
        return None


def _read_lines(path: str) -> list:
    # surrogateescape round-trips invalid bytes; split on \n only (not
    # str.splitlines(), which also splits on U+0085/2028/2029).
    with open(path, "r", encoding="utf-8", errors="surrogateescape", newline="") as f:
        return [x for x in re.split(r"(?<=\n)", f.read()) if x]


class AgeBoundedRotatingFileHandler(RotatingFileHandler):
    def __init__(self, *args, dater: Callable[[str], Optional[datetime]],
                 retention_days: int = LOG_RETENTION_DAYS, **kwargs):
        super().__init__(*args, **kwargs)
        self._dater = dater
        self._retention_days = retention_days

    def _date(self, line):
        """Run the dater; a raising dater means the line is undatable."""
        try:
            return self._dater(line)
        except Exception:
            return None

    def _first_dated(self, lines):
        for ln in lines:
            ts = self._date(ln)
            if ts is not None:
                return ts
        return None

    def purge_old(self, now: Optional[datetime] = None) -> dict:
        """Drop log entries older than the retention window. Never raises.

        Counts cover backups only. An active file that rolls over is counted
        as .1 afterward (so its lines appear in the counts of that pass).
        """
        removed_total = 0
        kept_total = 0
        try:
            if now is None:
                now = datetime.now(timezone.utc)
            cutoff = now - timedelta(days=self._retention_days)
            self.acquire()
            try:
                try:
                    if os.path.exists(self.baseFilename):
                        self.flush()
                        first = self._first_dated(_read_lines(self.baseFilename))
                        if first is not None and first < cutoff:
                            self.doRollover()
                except Exception:
                    _log.warning("Log retention: could not check the active log file; skipped")
                # backupCount == 0 means there are no backups: the active file
                # is never purged (only rolled over when its first line is old).
                for i in range(1, max(self.backupCount, 0) + 1):
                    p = f"{self.baseFilename}.{i}"
                    tmp = p + ".purge.tmp"
                    n_lines = 0
                    try:
                        if not os.path.isfile(p):
                            continue
                        lines = _read_lines(p)
                        n_lines = len(lines)
                        kept = []
                        keep = True  # undatable lines before any dated line are kept
                        for ln in lines:
                            ts = self._date(ln)
                            if ts is not None:
                                keep = ts >= cutoff
                            if keep:
                                kept.append(ln)
                        removed = n_lines - len(kept)
                        if removed == 0:
                            kept_total += n_lines
                            continue
                        if kept:
                            with open(tmp, "w", encoding="utf-8", errors="surrogateescape",
                                      newline="") as f:
                                f.write("".join(kept))
                                f.flush()
                                os.fsync(f.fileno())
                            os.replace(tmp, p)
                        else:
                            os.remove(p)
                        kept_total += len(kept)
                        removed_total += removed
                    except Exception:
                        _log.warning("Log retention: could not process a log backup; left unchanged")
                        kept_total += n_lines
                    finally:
                        try:
                            if os.path.exists(tmp):
                                os.remove(tmp)
                        except OSError:
                            pass
            finally:
                self.release()
            _log.info(f"Log retention purge ({os.path.basename(self.baseFilename)}): kept {kept_total}, removed {removed_total}")
        except Exception:
            _log.warning("Log retention purge failed")
        return {"removed": removed_total, "kept": kept_total}
