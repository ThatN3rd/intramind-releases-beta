import sys
import os
import subprocess
import win32serviceutil
import win32service
import win32event
import servicemanager

INSTALL_DIR = r"C:\Program Files\IntraMind"
DATA_DIR    = r"C:\ProgramData\IntraMind"
LOG_FILE    = os.path.join(DATA_DIR, "agent.log")

# sys.executable inside a pywin32 service points to pythonservice.exe, not python.exe.
# Resolve the real interpreter from the same directory as pythonservice.exe.
_svc_exe = sys.executable
PYTHON_EXE = os.path.join(os.path.dirname(_svc_exe), "python.exe")
if not os.path.exists(PYTHON_EXE):
    # Fallback: walk up one level (Scripts/ -> pythoncore-x.xx-64/)
    PYTHON_EXE = os.path.join(os.path.dirname(os.path.dirname(_svc_exe)), "python.exe")


def _read_port():
    port = "8767"
    env_path = os.path.join(DATA_DIR, ".env")
    try:
        with open(env_path) as f:
            for line in f:
                if line.startswith("EBMS_LIVE_PORT="):
                    port = line.strip().split("=", 1)[1]
    except Exception:
        pass
    return port


class EBMSLiveService(win32serviceutil.ServiceFramework):
    _svc_name_         = "EBMSLiveAgent"
    _svc_display_name_ = "EBMS Live Agent"
    _svc_description_  = "IntraMind EBMS Live Query Agent"

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self._stop_event = win32event.CreateEvent(None, 0, 0, None)
        self._process    = None

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        if self._process:
            self._process.terminate()
        win32event.SetEvent(self._stop_event)

    def SvcDoRun(self):
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, "")
        )
        port = _read_port()
        log  = open(LOG_FILE, "a")
        self._process = subprocess.Popen(
            [PYTHON_EXE, "-m", "uvicorn", "server:app",
             "--host", "0.0.0.0", "--port", port,
             "--log-config", os.path.join(INSTALL_DIR, "log_config.json")],
            cwd=INSTALL_DIR,
            stdout=log,
            stderr=log,
        )
        win32event.WaitForSingleObject(self._stop_event, win32event.INFINITE)
        log.close()


if __name__ == "__main__":
    if len(sys.argv) == 1:
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(EBMSLiveService)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        win32serviceutil.HandleCommandLine(EBMSLiveService)
