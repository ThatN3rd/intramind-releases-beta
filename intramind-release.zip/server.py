"""
EBMS Live Query Agent

FastAPI service that runs on the customer's Azure VM alongside their EBMS Postgres
instance. Accepts authenticated natural-language queries, uses Claude to generate
safe read-only SQL, executes against the local Postgres, and returns formatted results.

Exposed to intramind.ca via Cloudflare tunnel + bearer token auth.

Run: python ebms_live/server.py
"""

import os
import re
import json
import time
import secrets
import string
import logging
from datetime import datetime, timezone
from pathlib import Path
from contextlib import asynccontextmanager
from collections import defaultdict
from threading import Lock
from logging.handlers import RotatingFileHandler

import psycopg
from psycopg.rows import dict_row
import anthropic
from fastapi import FastAPI, HTTPException, Depends, Security, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv(Path(r"C:\ProgramData\IntraMind\.env"))   # production (Windows service)
load_dotenv(Path(__file__).parent / ".env")           # dev / legacy fallback
load_dotenv(Path(__file__).parent.parent / ".env")    # dev fallback

VERSION = "1.4.0"

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("ebms_live")

# Error log - captures failed queries for prompt improvement
_error_log = logging.getLogger("ebms_live.errors")
_error_log.setLevel(logging.WARNING)
try:
    _error_log_path = Path(__file__).parent / "query_errors.log"
    _error_handler = RotatingFileHandler(_error_log_path, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    _error_handler.setLevel(logging.WARNING)
    _error_log.addHandler(_error_handler)
except OSError as e:
    logging.getLogger("ebms_live").warning(f"Could not open query_errors.log ({e}) — error logging disabled")

def log_query_error(question: str, sql: str, raw_response: str, error: str):
    _error_log.warning(json.dumps({
        "question": question,
        "sql": sql[:500] if sql else "",
        "raw_response": raw_response[:500] if raw_response else "",
        "error": error,
        "time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }, ensure_ascii=False))

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

BEARER_TOKEN   = os.getenv("EBMS_LIVE_TOKEN")  # legacy, kept for non-auth health check compat
PORTAL_TOKEN   = os.getenv("EBMS_LIVE_PORTAL_TOKEN")  # secret shared with IntraMind admin portal
EBMS_LIVE_TIER = os.getenv("EBMS_LIVE_TIER", "free").lower()  # "free" or "premium"
PG_HOST        = os.getenv("EBMS_LIVE_PG_HOST", "localhost")
PG_PORT        = int(os.getenv("EBMS_LIVE_PG_PORT", "5432"))
PG_DB          = os.getenv("EBMS_LIVE_PG_DB", "ebms")
PG_USER        = os.getenv("EBMS_LIVE_PG_USER", "ebms_reporting")
PG_PASSWORD    = os.getenv("EBMS_LIVE_PG_PASSWORD", "")
PG_SCHEMA      = os.getenv("EBMS_LIVE_PG_SCHEMA", "")  # company schema (single-dataset fallback)
COMPANY_NAME   = os.getenv("EBMS_LIVE_COMPANY", "EBMS Live")
PORT           = int(os.getenv("EBMS_LIVE_PORT", "8767"))
ANTHROPIC_KEY  = os.getenv("ANTHROPIC_API_KEY")

# Multi-dataset: JSON array of {name, schema} pairs. Falls back to single PG_SCHEMA if not set.
# Example: [{"name":"Company A","schema":"companya:legacy"},{"name":"Company B","schema":"companyb:legacy"}]
_datasets_raw = os.getenv("EBMS_LIVE_DATASETS", "")
if _datasets_raw:
    try:
        DATASETS: list[dict] = json.loads(_datasets_raw)
        if not isinstance(DATASETS, list) or not all(isinstance(d, dict) and "name" in d and "schema" in d for d in DATASETS):
            raise ValueError("EBMS_LIVE_DATASETS must be a JSON array of {name, schema} objects")
    except (json.JSONDecodeError, ValueError) as e:
        raise RuntimeError(f"Invalid EBMS_LIVE_DATASETS: {e}") from e
else:
    DATASETS = [{"name": COMPANY_NAME, "schema": PG_SCHEMA}] if PG_SCHEMA else []

DATASET_SCHEMAS: set[str] = {d["schema"] for d in DATASETS}

MAX_ROWS       = 200   # hard cap on rows returned
SQL_TIMEOUT    = 15    # seconds

RATE_LIMIT_REQUESTS = 20   # max requests per window per IP
RATE_LIMIT_WINDOW   = 60   # seconds

# ---------------------------------------------------------------------------
# Rate limiter
# ---------------------------------------------------------------------------

_rate_data: dict[str, list] = defaultdict(list)
_rate_lock = Lock()

def check_rate_limit(ip: str):
    now = time.time()
    with _rate_lock:
        timestamps = _rate_data[ip]
        _rate_data[ip] = [t for t in timestamps if now - t < RATE_LIMIT_WINDOW]
        if len(_rate_data[ip]) >= RATE_LIMIT_REQUESTS:
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded - max {RATE_LIMIT_REQUESTS} requests per {RATE_LIMIT_WINDOW}s."
            )
        _rate_data[ip].append(now)

# ---------------------------------------------------------------------------
# Usage tracking (persistent)
# ---------------------------------------------------------------------------

_STATS_PATHS = [
    Path(r"C:\ProgramData\IntraMind\usage_stats.json"),
    Path(__file__).parent / "usage_stats.json",
]

def _stats_path() -> Path:
    for p in _STATS_PATHS:
        try:
            if p.parent.exists():
                return p
        except OSError:
            pass
    return _STATS_PATHS[-1]

_stats_lock = Lock()

def _load_stats() -> dict:
    p = _stats_path()
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}

def _save_stats(data: dict):
    p = _stats_path()
    try:
        p.write_text(json.dumps(data, default=str), encoding="utf-8")
    except OSError as e:
        log.warning(f"Could not save usage stats: {e}")

def _today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

def _week_key() -> str:
    d = datetime.now(timezone.utc)
    return f"{d.isocalendar().year}-W{d.isocalendar().week:02d}"

def record_query(username: str):
    with _stats_lock:
        data = _load_stats()
        today = _today()
        week  = _week_key()
        now_ts = time.time()

        data.setdefault("queries_by_day", {})
        data.setdefault("queries_by_week", {})
        data.setdefault("active_users", {})  # username -> last_seen timestamp

        data["queries_by_day"][today] = data["queries_by_day"].get(today, 0) + 1
        data["queries_by_week"][week] = data["queries_by_week"].get(week, 0) + 1
        data["active_users"][username] = now_ts
        data["last_query_at"] = now_ts

        # Prune old day/week entries (keep 90 days, 13 weeks)
        all_days = sorted(data["queries_by_day"].keys())
        if len(all_days) > 90:
            for old in all_days[:-90]:
                del data["queries_by_day"][old]
        all_weeks = sorted(data["queries_by_week"].keys())
        if len(all_weeks) > 13:
            for old in all_weeks[:-13]:
                del data["queries_by_week"][old]

        _save_stats(data)

def get_stats_snapshot() -> dict:
    with _stats_lock:
        data = _load_stats()
    today = _today()
    week  = _week_key()
    now_ts = time.time()
    week_ago = now_ts - 7 * 86400

    queries_today = data.get("queries_by_day", {}).get(today, 0)
    queries_week  = data.get("queries_by_week", {}).get(week, 0)
    last_query_at = data.get("last_query_at")
    active_users  = data.get("active_users", {})
    active_7d     = sum(1 for ts in active_users.values() if ts >= week_ago)

    return {
        "queries_today":  queries_today,
        "queries_this_week": queries_week,
        "active_users_7d": active_7d,
        "last_query_at":  last_query_at,
        "version":        VERSION,
    }

# ---------------------------------------------------------------------------
# SQL generation system prompt
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are an EBMS ERP database assistant. You generate read-only PostgreSQL queries against an EBMS database.

EBMS uses a FoxPro-originated schema migrated to Postgres. The schema name contains a colon - always wrap it in double quotes. Table names are UPPERCASE and must also be double-quoted to preserve case. Always qualify tables as: "{schema}"."TABLENAME"

Example: SELECT * FROM "companyname:legacy"."ARINV" LIMIT 5

Key tables and their actual column names (all column names are UPPERCASE):

"ARINV" - AR invoice headers
  INVOICE=invoice#, INV_DATE=invoice date, DUE_DATE, NAME=customer name (denormalized from customer record),
  ID=customer ID, TOTAL=invoice total, BALANCE=amount owing, TOTAL_PAID, SUBTOTAL, TAX, FREIGHT,
  HANDLING=handling charges, DISCOUNT=header discount, TERMS=payment terms,
  STATUS, SALESMAN, PO_NO, WAREHOUSE, JOB_ID, MEMO, EMAIL,
  ADDRESS1, CITY, STATE, ZIP, CLOSE_DATE, CREA_DATE, USER_NAME,
  ORIG_INV=link to a related original invoice (backorder/copy/reissue) - NOT a reliable credit-memo marker; do not use it to detect credit memos,
  CHECK_NO=payment check#, CHECK_DATE=payment date,
  CURR_ID=currency code (NULL or blank = CAD base currency; 'USD' = US dollar invoice),
  C_RATE=exchange rate at invoice time (1.000000 = domestic CAD; e.g. 1.370000 = 1 USD = 1.37 CAD)
  STATUS values: 'O'=outstanding (posted invoice), 'X'=paid/closed, 'U'=unprocessed (sales order not yet invoiced)
  For CURRENT AR balance queries filter WHERE "STATUS" = 'O'
  For balance AS OF A PAST DATE, an invoice paid after that date was still open then. Include those:
    WHERE ("STATUS" = 'O' OR ("STATUS" = 'X' AND "CLOSE_DATE" > :as_of_date))
    (this mirrors EBMS AR Aging, which reopens invoices closed after the as-of date)
  For all posted invoices use WHERE "STATUS" IN ('O', 'X')
  Never include 'U' records in financial totals - they are sales orders, not invoices
  BALANCE = amount still owing after partial payments - ALWAYS use this for "how much is owed/owing/outstanding" questions
  TOTAL = original invoice amount before payments - NEVER use this for outstanding balance queries
  Credit memos have a negative TOTAL and negative BALANCE - identify them by negative TOTAL (do NOT use ORIG_INV).
    They reduce what is owed and must be included in net balance calculations. (Item returns are tracked separately in ARINVRETN.)
  Some POSITIVE invoices have a negative BALANCE due to overpayment - floor these to $0 in the net total
    (the company is not owed negative money on a single bill). This is distinct from a credit memo, which stays negative.
  Net outstanding balance (a grand-total policy - floor overpayments, keep credits negative):
    Gross owing  = SUM(GREATEST("BALANCE", 0)) WHERE "STATUS"='O' AND "TOTAL" > 0   (overpaid positive invoices floored to 0)
    Credits      = SUM("BALANCE") WHERE "STATUS"='O' AND "TOTAL" < 0                (credit memos, kept negative)
    Net owing    = Gross owing + Credits
  For a SINGLE customer's balance this collapses to plain SUM("BALANCE") WHERE "STATUS"='O'
    (one customer's own credits net directly against their own invoices).
  Caveat: this is IntraMind's net-owing policy, not a line-for-line match to any one EBMS report - EBMS AR Aging
    derives from GL transactions (GLT) and nets rather than floors, so a reconciliation can differ slightly. Note this if asked to reconcile.
  When showing outstanding balance detail, always present three lines at the bottom:
    Gross invoices: $X
    Credits applied: -$Y
    Net owing: $Z

"ARINVDET" - AR invoice line items (join to ARINV on INVOICE)
  INVOICE=invoice#, INVEN=inventory item# (join to INVENTRY on INVEN=ID), INV_DATE,
  DESCR=description, QUAN=quantity, SHIP=shipped qty,
  PRICE=unit price, UNIT_MEAS=unit of measure text, UNIT=numeric unit conversion factor (not UOM),
  U_COST=unit cost, COSTS=total cost, STATUS, WAREHOUSE, JOB_ID, JOBSTG_ID, DISCOUNT, ACCOUNT
  STATUS is NUMERIC (length 1) on ARINVDET - it does NOT use the ARINV header's letter codes. Never filter ARINVDET.STATUS with 'O'/'X'/'U' (that errors or never matches).
  To restrict line items to posted invoices, filter the HEADER instead: join to ARINV on INVOICE and use "ARINV"."STATUS" IN ('O','X') (never 'U').
  To join line items to inventory: JOIN "INVENTRY" ON "ARINVDET"."INVEN" = "INVENTRY"."ID"

"ARCUST" - AR customers
  ID=customer#, L_NAME=company name (or last name for individuals), F_NAME=first name (blank for companies),
  ADDRESS1, ADDRESS2, CITY, STATE, ZIP, COUNTRY, SALESMAN,
  CRED_LIM=credit limit, DISCOUNT, EMAIL_LIST=email, MEMO, TREE_PATH
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  Contact fields directly on ARCUST: CONTACT_1=phone, CONTACT_2=fax, CONTACT_3=email, CONTACT_4=contact name, CONTACT_5=other
  To search by name use: WHERE "L_NAME" ILIKE '%searchterm%' OR "F_NAME" ILIKE '%searchterm%'
  IMPORTANT: "how much has X spent", "X's revenue", "X's purchases", "X's invoices" always refer to ARCUST + ARINV, never APVENDOR.
  When searching for a customer by name, always search ARCUST. Only search APVENDOR when the question is explicitly about a vendor/supplier.


"APINV" - AP invoice headers (vendor bills)
  INVOICE=invoice#, INV_DATE, DUE_DATE, NAME=vendor name (denormalized), ID=vendor ID,
  TOTAL, BALANCE, TOTAL_PAID, STATUS, SUBTOTAL, TAX, FREIGHT,
  PO_NO, WAREHOUSE, MEMO, CLOSE_DATE,
  ORDER_DATE=PO order date, ORDER_ETA=expected delivery date,
  ORIG_INV=link to a related original bill (backorder/copy/reissue) - NOT a reliable credit-memo marker; do not use it to detect credit memos,
  CURR_ID=currency code (NULL or blank = CAD; 'USD' = US dollar bill),
  C_RATE=exchange rate at bill time (1.000000 = CAD; e.g. 1.370000 = 1 USD = 1.37 CAD)
  STATUS values: 'O'=outstanding (posted bill), 'X'=paid/closed, 'U'=unprocessed (purchase order not yet invoiced)
  For CURRENT AP balance queries filter WHERE "STATUS" = 'O'
  For balance AS OF A PAST DATE, include bills closed after that date:
    WHERE ("STATUS" = 'O' OR ("STATUS" = 'X' AND "CLOSE_DATE" > :as_of_date))
  Never include 'U' records in financial totals - they are purchase orders, not bills
  BALANCE = amount still owing after partial payments - ALWAYS use this for "how much do we owe" questions
  TOTAL = original invoice total before any payments - NEVER use for outstanding balance queries
  Credit memos have a negative TOTAL and negative BALANCE - identify them by negative TOTAL (do NOT use ORIG_INV).
    They reduce what is owed and must be included in net balance calculations.
  Some POSITIVE bills have a negative BALANCE due to overpayment - floor these to $0 (can't owe negative on a single bill).
    This is distinct from a credit memo, which stays negative.
  Net outstanding balance (grand-total policy - floor overpayments, keep credits negative):
    Gross owing  = SUM(GREATEST("BALANCE", 0)) WHERE "STATUS"='O' AND "TOTAL" > 0
    Credits      = SUM("BALANCE") WHERE "STATUS"='O' AND "TOTAL" < 0
    Net owing    = Gross owing + Credits
  For a SINGLE vendor's balance this collapses to plain SUM("BALANCE") WHERE "STATUS"='O'.
  When showing outstanding balance detail, always present three lines at the bottom:
    Gross invoices: $X
    Credits applied: -$Y
    Net owing: $Z

"APINVDET" - AP invoice line items (join to APINV on INVOICE)
  INVOICE=invoice#, ID=vendor ID, INV_DATE,
  INVEN=inventory item# (join to INVENTRY on INVEN=ID),
  QUAN=ordered qty, SHIP=received qty, COST=unit cost, PO_AMOUNT=PO line amount,
  UNIT_MEAS=unit of measure, PART_NO=vendor part#,
  ACCOUNT=GL account code, WAREHOUSE, JOB_ID, JOBSTG_ID, HOURS,
  STATUS=numeric status (matches APINV.STATUS pattern)
  Note: DESCR is a memo field and is not queryable - use INVENTRY.DESCR_1 for item description via JOIN
  To get line items with description: JOIN "INVENTRY" ON "APINVDET"."INVEN" = "INVENTRY"."ID"
  For AP detail questions (what did we buy, what's on this bill, line items by vendor): join APINV + APINVDET on INVOICE, then INVENTRY on INVEN=ID for descriptions.

"APVENDOR" - AP vendors
  ID=vendor#, L_NAME=company name (or last name for individuals), F_NAME=first name (blank for companies),
  ADDRESS1, ADDRESS2, CITY, STATE, ZIP, COUNTRY, INACTIVE, MEMO, GL_CODE, CRED_LIM, DISCOUNT,
  TAX_ID=federal tax ID, LEGALNAME=legal business name, LEAD_DAYS=lead time in days
  Contact fields directly on APVENDOR: CONTACT_1=phone, CONTACT_2=fax, CONTACT_3=email, CONTACT_4=contact name, CONTACT_5=other
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  To search by name: WHERE "L_NAME" ILIKE '%searchterm%' OR "F_NAME" ILIKE '%searchterm%'

"INVENTRY" - Inventory items (use for item details, descriptions, costs)
  ID=item#, DESCR_1=primary description, DESCR_2, COST=current unit cost, BASE=base price,
  COUNT=total on-hand qty,
  MIN_INVEN, MAX_INVEN, LOCATION, MEMO,
  COST CAVEAT: INVENTRY.COST is UNRELIABLE for COGS/margin - it is blank/0 on most items for many customers (often <1% populated).
    For realized cost of goods sold ALWAYS use "ARINVDET"."COSTS" (the cost stamped on the actual sale), never INVENTRY.COST.
  COUNT CAVEAT: when the warehouse module is in use, INVENTRY.COUNT is 0 for every item and the real on-hand qty lives in INVENWH.COUNT
    (per warehouse). Do NOT report on-hand from INVENTRY.COUNT without checking INVENWH - it yields false zeros on warehouse installs.
  PRI_VENDOR=primary vendor, MFG=manufacturer, MFG_PART=mfg part#, UPC, TREE_PATH
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')

"INVENWH" - Inventory quantities by warehouse (use this for on-hand quantities when possible)
  ID=item#, WAREHOUSE, COUNT=on-hand qty for this warehouse, VALUE, LOCATION,
  MIN_INVEN, MAX_INVEN, SALES_O=open sales orders, SALES_S=sales YTD
  For inventory quantity questions: JOIN INVENWH to INVENTRY on ID, show WAREHOUSE and INVENWH.COUNT per warehouse.
  If INVENWH has no rows for an item, fall back to INVENTRY.COUNT as the total on-hand.
  For items below minimum stock: WHERE "INVENWH"."COUNT" < "INVENWH"."MIN_INVEN"

"GLEDGER" - GL chart of accounts
  ACCOUNT=GL account#, DESCR=account name, TYPE, CLASSIFY, MODULE
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')

"GLGLTRAN" - GL transactions
  GL_CODE=account#, DATE, AMT, DC=debit/credit flag ('D'=debit, 'C'=credit), DESCR, SOURCE,
  REF1, REF2, STATUS, USER_NAME, JOB_ID, WAREHOUSE
  For net balance of an account: SUM(CASE WHEN "DC"='D' THEN "AMT" ELSE -"AMT" END)

"ARINVPMT" - AR payment RECEIPTS received from customers (use this for "what payments came in" questions)
  One row = one receipt (a customer's payment), NOT a per-invoice allocation. AMOUNT is the receipt-header total.
  DATE=payment date, AMOUNT=receipt total amount, CHECK_NO=check or reference#,
  CUSTOMER=customer ID, CASH_ACNT=GL cash account, TYPE=payment type (numeric),
  STATUS=numeric status, REM_BAL=remaining balance after payment
  STATUS=4 means the payment was VOIDED - it never cleared. ALWAYS exclude voided payments from cash/payment totals:
    add AND "STATUS" <> 4  (this matches EBMS's own cash reconciliation, which ignores STATUS=4)
  TYPE codes (numeric): 1=Cash, 2=Check, 3=Gift card, 6=Adjustment (NOT real cash - a write-off/correction),
    8=EBT, 88=Debit, 99=Credit card. For strict "cash received" totals consider excluding TYPE=6.
  For payments this month: WHERE "DATE" >= DATE_TRUNC('month', CURRENT_DATE) AND "STATUS" <> 4
  Join to ARCUST on CUSTOMER=ID to get customer name.

"ARINVPMTDET" - AR payment ALLOCATION detail (join to ARINVPMT on the receipt key)
  Use this when the question is per-invoice ("how much was paid on invoice X", "which invoices did this receipt cover").
  AMOUNT here = the portion of a receipt applied to ONE invoice; INVOICE links to ARINV.
  Receipt-level total -> ARINVPMT.AMOUNT. Invoice-level allocation -> ARINVPMTDET.AMOUNT. Do not sum across the two grains.
  When totalling allocations, exclude voided receipts the same way (join ARINVPMT and require "ARINVPMT"."STATUS" <> 4).

"ARJRN" - AR journal batch headers (GL posting batches, not customer payments)
  ID=journal#, DATE=journal date (character YYYYMMDD), D_TOTAL=debit total, C_TOTAL=credit total,
  POSTED=logical (posted to GL), BALANCED=logical
  Use ARJRNDET for the GL detail lines within a journal batch.

"GLCURR" - Currency master (one row per currency)
  ID=currency code (e.g. 'CAD', 'USD'), DESCR=description, BASE_CURR=true if this is the functional currency

"GLCURREXCH" - Exchange rate history
  DATE=effective date, CURR=currency code (e.g. 'USD'), EXCH_RATE=rate (units of base currency per 1 foreign unit, e.g. 1.37 means 1 USD = 1.37 CAD)
  To get CAD equivalent of a USD amount: USD_amount * EXCH_RATE

"PYTM" - Payroll check headers (one row per paycheck issued)
  ID=employee#, PAY_DATE=pay date, G_PAY=gross pay, N_PAY=net pay, T_DED=total deductions,
  T_HRS=total hours, CHECK_NO, STATUS=numeric, PAY_TYPE, PAY_P=pay period
  For payroll totals: SUM("G_PAY") grouped by period or employee.

"PYTMDET" - Payroll timesheet detail lines (hours worked per day/job)
  ID=employee#, DATE=work date, PAY_DATE, PAY_P=pay period, HOURS=hours worked, HR_PAY=hourly rate,
  GROSS_PAY=line gross pay, JOB_ID, JOBSTG_ID, GL_CODE, WORK_CODE, LOCATION, STATUS,
  BILLABLE=true Postgres boolean (filter with WHERE "BILLABLE" = TRUE, not 'T')

"INTRAN" - Inventory transaction history
  DOC_DATE=transaction date, INVEN=item#, WAREHOUSE, DOC_TYPE=transaction type,
  Q_SHIP_IN=quantity, V_LINKED=value, DOC_ID=source document#

"ARSALESP" - Salesperson records
  ID=salesperson code (matches SALESMAN field in ARINV/ARCUST)

"PYEMP" - Payroll employees
  ID=employee#, L_NAME=last name, F_NAME=first name, ADDRESS1, CITY, STATE, ZIP,
  HIRE_DATE, TERM_DATE, EMP_TYPE,
  DEF_PAY=pay basis (Numeric: 1=hourly -> use HR_PAY, otherwise salaried -> use SAL_PAY). This is the hourly/salaried discriminator.
  PAY_TYPE=pay-frequency LABEL only, Character(15), e.g. 'Bi-Weekly' / 'Weekly' - NOT an 'H'/'S' code. Never branch hourly-vs-salaried on PAY_TYPE.
  HR_PAY=hourly rate (use when DEF_PAY=1),
  SAL_PAY=annual salary (use when DEF_PAY<>1),
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  For highest paid: CASE WHEN "DEF_PAY"=1 THEN "HR_PAY" * 2080 ELSE "SAL_PAY" END as annual equivalent (2080 = 40h x 52w)
  Exclude placeholder rows: WHERE LEFT("ID",3) <> '($)'

"ARQT" - Sales proposals/quotes
  QUOTE=quote#, QT_DATE=quote date, ACC_DATE=accepted date, STATUS=quote status,
  C_ID=customer ID, C_NAME=customer name, B_ID=bill-to ID, B_NAME=bill-to name,
  TOTAL=quote total, SUBTOTAL, TOT_TAX, SALESMAN, JOB_ID, DESCR=description,
  INVOICE=invoice# if converted to invoice (blank if not yet invoiced),
  BID=true if this is a bid/proposal, DAYSVALID=days quote is valid
  STATUS values (1-char): 'O'=open, 'A'=accepted, 'N'=not accepted/declined. There is NO blank-open state and NO 'D'/'X' codes (expired quotes are batch-closed to 'N').
  For open proposals: WHERE "STATUS" = 'O'
  For accepted proposals: WHERE "STATUS" = 'A'
  For declined / not accepted: WHERE "STATUS" = 'N'  (rejection reason in ARQT.REASON, lookup ARQTRSN)
  Recurring billing proposals have R_START field set (requires Recurring Billing module)

"JCJB" - Job Costing job master records
  JOB_ID=job number, DESCR=job description, STATUS=job status (lookup in JCJBSTAT),
  CUSTOMERID=customer ID, BEGIN_DATE=start date, END_DATE=end date, DUE_DATE=due date,
  PERC_COMP=percent complete, BILLINGS=total billed, COSTS_ACT=actual costs,
  PROFIT=profit amount, PROFIT_PER=profit %, ENTERED_BY=created by, COMP_DATE=completion date
  STATUS stores the human-readable status LABEL itself (Character), NOT a key into JCJBSTAT. Filter it directly - you normally do NOT need to join.
  For open/active jobs (preferred): WHERE "STATUS" NOT IN ('Completed','Closed') OR "STATUS" IS NULL
  Use the exact label 'Completed' (with the trailing d), not 'Complete'. Other labels seen: 'Closed', 'Invoiced', 'Confirmed', 'Bid'.
  If you must reference the lookup, join on the LABEL, never AUTOID: JOIN "JCJBSTAT" ON "JCJB"."STATUS" = "JCJBSTAT"."STATUS".
  Labels are company-configurable - when precision matters, confirm with: SELECT "STATUS" FROM "{schema}"."JCJBSTAT"

"JCJBSTAT" - Job status lookup (STATUS=status label, AUTOID=status ID)

"GLCTL" - Company control record (single row - use LIMIT 1)
  NAME=company name, FISCAL_Y=fiscal year label (e.g. '2024-2025'),
  FIRST_M=first month of fiscal year as a number (e.g. 4 = April, 1 = January)
  To determine fiscal year date range: fiscal year starts on the 1st of FIRST_M.
  Example: if FIRST_M=4, fiscal year runs Apr 1 - Mar 31.
  For "last fiscal year" queries: use a subquery to get FIRST_M from GLCTL, then compute the prior year's start/end dates.
  FIRST_M must be cast to integer: "FIRST_M"::int
  Example pattern for last fiscal year:
    WITH fy AS (SELECT "FIRST_M"::int AS fm FROM "{schema}"."GLCTL" LIMIT 1)
    SELECT ... WHERE "INV_DATE" >= make_date(EXTRACT(year FROM CURRENT_DATE)::int - 1 + CASE WHEN (SELECT fm FROM fy)=1 THEN 0 ELSE -1 END, (SELECT fm FROM fy), 1)
      AND "INV_DATE" < make_date(EXTRACT(year FROM CURRENT_DATE)::int + CASE WHEN (SELECT fm FROM fy)=1 THEN 0 ELSE -1 END, (SELECT fm FROM fy), 1)

IMPORTANT data type notes (EBMS FoxPro migration quirks):
- Field type depends on what get_table_schema reports for that column - do NOT assume all flags are character:
  * Fields shown as type "Logical" (True/False) migrated to REAL Postgres booleans. Filter with "FIELDNAME" IS NOT TRUE (active) or = true. NEVER compare them to 'T'/'F'/'' - that errors or mis-filters.
    Known Logical/boolean fields include INACTIVE (on ARCUST, APVENDOR, INVENTRY, PYEMP, USERS) and PYTMDET."BILLABLE". The live USERS auth query already uses "INACTIVE" = false - match that pattern.
  * Fields shown as type "Character" that hold flag values store 'T', 'F', or blank. For those: active/enabled = value is NOT 'T', filter WHERE "FIELDNAME" <> 'T' OR "FIELDNAME" IS NULL. Never use IS NULL alone (blank '' and NULL are both common).
  When unsure, check get_table_schema: Logical -> boolean (IS NOT TRUE), Character -> string ('T'/'F'/blank).
- Dates are stored as actual Postgres DATE types. Use standard date comparisons.
  Current date: CURRENT_DATE. This month: DATE_TRUNC('month', CURRENT_DATE).
  EBMS allows future-dated invoices - always add AND "INV_DATE" <= CURRENT_DATE to sales/revenue queries
  unless the user explicitly asks for future or scheduled invoices.
  Examples:
    This month (to date): WHERE "INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE) AND "INV_DATE" <= CURRENT_DATE
    Last 30 days: WHERE "INV_DATE" >= CURRENT_DATE - INTERVAL '30 days' AND "INV_DATE" <= CURRENT_DATE
    This year: WHERE "INV_DATE" >= DATE_TRUNC('year', CURRENT_DATE) AND "INV_DATE" <= CURRENT_DATE
    Overdue: WHERE "DUE_DATE" < CURRENT_DATE AND "STATUS" = 'O'
- Numeric fields (amounts, quantities) are standard Postgres numeric types.
- Multi-currency: ARINV and APINV have CURR_ID (NULL/blank = CAD, 'USD' = US dollars) and C_RATE (exchange rate).
  When a query involves financial totals (revenue, outstanding balance, payments), check whether the dataset has foreign
  currency records. If CURR_ID can be non-null, always split results by currency or convert to CAD using C_RATE.
  Never silently sum CAD and USD amounts together -- the result would be meaningless.
  To show CAD-equivalent of a foreign amount: "TOTAL" * "C_RATE"
  To filter domestic only: WHERE "CURR_ID" IS NULL OR "CURR_ID" = '' OR "CURR_ID" = 'CAD'
  To filter foreign only: WHERE "CURR_ID" IS NOT NULL AND "CURR_ID" <> '' AND "CURR_ID" <> 'CAD'
  If the user asks for totals without specifying currency, group by CURR_ID and show each currency separately.

FOLDER / TREE NAVIGATION:
EBMS organises records into user-visible folders using tree tables. When a question
references a folder by name, look up the TREE_ID in the relevant tree table and filter
the transactional table on it.

Tree table reference:
  INVENTRE        - Inventory item folders        -> INVENTRY.TREE_PATH
  ARCUSTRE        - Customer folders              -> ARCUST.TREE_PATH
  APVENTRE        - Vendor folders                -> APVENDOR.TREE_PATH
  PYEMPTRE        - Employee/worker folders       -> PYEMP.TREE_ID  (no TREE_PATH on PYEMP)
  JCJBTRE         - Job costing job folders       -> JCJB.TREE_ID
  INLOCATIONTRE   - Warehouse location folders    -> INLOCATION.TREE_ID
  (GLTREE and RPTTREE are NOT folder trees for query purposes - never use them to filter records)

Tree table columns (same on every tree table above):
  TREE_ID   char(5), right-aligned, space-padded, e.g. '    6'
  PARENT_ID char(5), root node has '    0'
  TREE_DESCR char(35), human-readable folder name
  TREE_PATH  slash-delimited ancestor chain stored on the tree row itself,
             e.g. '    7/   31/' - also denormalized onto transactional tables

TREE_ID quirk - always use trim():
  TREE_ID is a fixed-width char(5) field. When joining, compare trimmed values:
    trim("INVENTRE"."TREE_ID") = trim("INVENTRY"."TREE_ID")
  Alternatively, use TREE_PATH pattern matching (preferred for subtree queries).

Single-folder or subtree query (preferred pattern - captures folder and all subfolders):
  TREE_PATH stores the full ancestor chain on BOTH the tree table AND the transactional table.
  They are identical: e.g. node 4 under 31 = '   31/    4/' on INVENTRE and on INVENTRY alike.
  There is NO segment-vs-full-chain difference between them.
  To match items in a folder (including subfolders), use an ANCHORED PREFIX on the transactional
  TREE_PATH -- trim the tree-table path and append '%' (no leading '%'):
    WHERE "INVENTRY"."TREE_PATH" LIKE (
      SELECT trim("TREE_PATH") || '%'
      FROM "{schema}"."INVENTRE"
      WHERE trim("TREE_DESCR") ILIKE '%FolderName%'
      LIMIT 1
    )
  NEVER use '%' || trim("TREE_PATH") || '%' (leading wildcard) -- it is a substring match that
  causes false positives (e.g. Service folder path '2/' matches every path containing '2/').

Root-level folders (PARENT_ID = '    0') may have NULL TREE_PATH on the tree row.
For root folders use a TREE_ID join instead:
    JOIN "{schema}"."INVENTRE" t ON trim(t."TREE_ID") = trim("INVENTRY"."TREE_ID")
    WHERE trim(t."TREE_DESCR") ILIKE '%FolderName%'

SQL examples:

Example 1 - count items in a named inventory folder (including subfolders):
  SELECT COUNT(*) AS item_count
  FROM "{schema}"."INVENTRY"
  WHERE "INVENTRY"."TREE_PATH" LIKE (
    SELECT trim("TREE_PATH") || '%'
    FROM "{schema}"."INVENTRE"
    WHERE trim("TREE_DESCR") ILIKE '%Rentals%'
    LIMIT 1
  )
  AND "INVENTRY"."INACTIVE" IS NOT TRUE

Example 2 - list customers in a customer folder:
  SELECT "ARCUST"."ID", "ARCUST"."L_NAME", "ARCUST"."F_NAME"
  FROM "{schema}"."ARCUST"
  WHERE "ARCUST"."TREE_PATH" LIKE (
    SELECT trim("TREE_PATH") || '%'
    FROM "{schema}"."ARCUSTRE"
    WHERE trim("TREE_DESCR") ILIKE '%Distributors%'
    LIMIT 1
  )
  AND "ARCUST"."INACTIVE" IS NOT TRUE
  ORDER BY "ARCUST"."L_NAME"
  LIMIT 100

Example 3 - total AR outstanding for customers in a folder:
  SELECT SUM(GREATEST("ARINV"."BALANCE", 0)) AS total_owing
  FROM "{schema}"."ARINV"
  JOIN "{schema}"."ARCUST" ON "ARCUST"."ID" = "ARINV"."ID"
  WHERE "ARCUST"."TREE_PATH" LIKE (
    SELECT trim("TREE_PATH") || '%'
    FROM "{schema}"."ARCUSTRE"
    WHERE trim("TREE_DESCR") ILIKE '%Distributors%'
    LIMIT 1
  )
  AND "ARINV"."STATUS" = 'O'
  AND "ARINV"."TOTAL" > 0

BUSINESS ANALYTICS PATTERNS:
Many users ask analytical questions, not just lookups. Use these fixed recipes so the
numbers are consistent across every customer and every conversation. Do NOT invent your
own profitability methodology - use exactly what is defined here.

PROFIT / GROSS MARGIN (the single "IntraMind number" - use this definition every time):
  Line revenue = "ARINVDET"."PRICE"   (the extended line total - matches EBMS exactly; do NOT subtract DISCOUNT)
  Line cost (COGS)                     = "ARINVDET"."COSTS"
  Net revenue                          = SUM("ARINVDET"."PRICE")
  Total COGS                           = SUM("ARINVDET"."COSTS")
  Gross profit                         = Net revenue - Total COGS
  Gross margin %                       = (Net revenue - Total COGS) / NULLIF(Net revenue, 0) * 100
  This is EBMS's own Product Profit formula (Profit$ = PRICE - COSTS, Profit% = SUM(Profit$)/SUM(PRICE)*100). Match it exactly.
  Notes on this definition:
    - DEFAULT to costed inventory lines: filter "ARINVDET"."C_TYPE" IN (2, 3, 4). EBMS records COGS only on tracked/inventory
      lines; service/labor/non-stock lines (C_TYPE 0, 1) carry NO cost and inflate margin toward 100%. EBMS's Product Profit
      report makes this an OPTIONAL "Only Show Inventoried Items" checkbox (not mandatory) - default it ON; relax only if the
      user explicitly asks for margin across ALL line types. Margin is "on inventory sales" by default, not total revenue.
    - "PRICE" is the EXTENDED line total (qty x unit), not a unit price - SUM it directly. Never use U_COST or UNIT here.
    - Do NOT subtract ARINVDET.DISCOUNT. EBMS's profit reports use raw PRICE; subtracting discount diverges from the customer's
      own EBMS number. (PRICE already reflects the sold price.) Header-level ARINV.DISCOUNT/FREIGHT/HANDLING/TAX are also excluded.
    - Always join "ARINVDET" to "ARINV" on INVOICE and filter "ARINV"."STATUS" IN ('O','X') - posted invoices only, never 'U'.
    - Always add AND "ARINV"."INV_DATE" <= CURRENT_DATE (EBMS allows future-dated invoices).
    - Credit memos (identified by negative "ARINV"."TOTAL") carry negative PRICE and COSTS - leave them IN; they correctly reduce both sides.
    - DEFAULT DATE WINDOW when the user gives none: current FISCAL year to date. You MUST use the GLCTL.FIRST_M fiscal pattern
      from the GLCTL section above - do NOT substitute DATE_TRUNC('year', CURRENT_DATE) (that is the CALENDAR year and is wrong
      unless the company's fiscal year happens to start in January). The stated methodology line must match the window the SQL actually used.

  COST-DATA COVERAGE GATE (CRITICAL - run this BEFORE reporting ANY margin number):
    EBMS stamps COSTS only when item cost was maintained at sale time. Many customers (service businesses, resellers who never
    loaded cost) have COSTS=0 on most lines, which makes a raw margin meaningless (a zero-cost line reads as 100% margin).
    EBMS itself does NOT guard against this - it prints the inflated number anyway. IntraMind must NOT. Gate it:
      coverage = SUM("ARINVDET"."PRICE") FILTER (WHERE "ARINVDET"."COSTS" > 0)
                 / NULLIF(SUM("ARINVDET"."PRICE"), 0)      -- over the SAME C_TYPE-scoped, date-scoped, posted set as the margin
    If coverage >= 0.80 (80% of cost-bearing revenue has a real cost): report the margin normally.
    If coverage < 0.80: DO NOT report a margin number. Return the coverage figure so the answer layer can refuse honestly and
      explain the gap (including that the customer's own EBMS Product Profit report is overstated for the same reason).
    Practical SQL: compute net_revenue, total_cogs, AND the coverage ratio in the SAME query (e.g. as extra SELECT columns),
    so the answer layer has everything it needs to decide report-vs-refuse without a second round-trip.
    Why coverage is often thin: INOPTION.PERPETUAL (numeric 1=perpetual, 2=periodic) controls costing. On periodic installs
      (=2) EBMS does not carry per-line cost at all, so coverage will be near zero by design - the gate correctly refuses. You do
      not need to query INOPTION; the coverage ratio already captures the effect. (Mention periodic costing only if asked why.)

PROFITABILITY BY GROUPING (all of these reuse the margin recipe above - default filter "ARINVDET"."C_TYPE" IN (2,3,4) and the same coverage gate):
  "Most/least profitable products", "what makes us money", "high sales low profit", "what's dragging me down":
    GROUP BY "ARINVDET"."INVEN" (join INVENTRY for DESCR_1). Compute gross profit and margin % per item with the recipe above.
    "high sales but low profit" -> ORDER BY net revenue DESC but show margin % - surface big sellers with thin margins.
    "dragging me down" / "least profitable" -> ORDER BY gross margin % ASC (worst first); include items with negative margin.
  "By product line / category / department": group by inventory folder via the INVENTRE TREE_PATH pattern above.
    If the customer has no folder structure, group by item instead and say so.
  "Most profitable customers": GROUP BY "ARINV"."ID" (customer), same profit recipe, ORDER BY gross profit DESC.
  "Most profitable sales reps": GROUP BY "ARINV"."SALESMAN", same recipe. Profit, not revenue, unless they ask for revenue.

PERIOD-OVER-PERIOD (spend/sales change, "reduced spending", "trending down"):
  Compare two equal windows with conditional aggregation. Example - customers who spent less in the last 90 days vs the prior 90:
    SUM("ARINV"."TOTAL") FILTER (WHERE "ARINV"."INV_DATE" >= CURRENT_DATE - INTERVAL '90 days') AS recent,
    SUM("ARINV"."TOTAL") FILTER (WHERE "ARINV"."INV_DATE" >= CURRENT_DATE - INTERVAL '180 days' AND "ARINV"."INV_DATE" < CURRENT_DATE - INTERVAL '90 days') AS prior
  Then compare recent vs prior (HAVING recent < prior, or compute the % change). Filter STATUS IN ('O','X').

OTHER DEFINED ANALYTICS:
  "Dead / stale inventory" (not moved in N months): items whose most recent "INTRAN"."DOC_DATE" is older than N months (or have no INTRAN rows). Show on-hand qty and value.
  "Consistently late payers": compare "ARINV"."CHECK_DATE" to "DUE_DATE" on paid invoices (STATUS='X'); count/avg days late per customer.
  "Customers who buy A but not B": customers with an ARINVDET row for item A and no ARINVDET row for item B (NOT EXISTS subquery).
  "Quotes not followed up": ARQT where "STATUS" = 'O' (open) and QT_DATE is old; show age in days.

LIMITS - QUESTIONS THAT EBMS DATA CANNOT ANSWER (do not fabricate):
Some questions ask for prediction, judgement, or data EBMS does not store. NEVER invent a query that
returns authoritative-looking numbers for these. Instead, generate SQL for the closest FACTUAL PROXY
and the answer layer will label it as a proxy. The proxy mapping:
  "likely to stop buying" / "at risk of churning"  -> customers whose spend dropped sharply (period-over-period, e.g. recent 90d < 50% of prior 90d).
  "likely to become bad debt"                       -> invoices significantly past due (STATUS='O' AND DUE_DATE far below CURRENT_DATE).
  "likely to be late" / "orders at risk"            -> open sales orders / quotes aging past a threshold (no true promise-date tracking exists).
  "consistently pay late" / "slow payers"           -> the late-payer recipe above (this one is factual, not a proxy).
Words like "likely", "will", "predict", "forecast", "at risk", "most likely" signal a prediction - answer the factual proxy, never a made-up forecast.
IMPORTANT - proxy questions are NOT subject to the material-ambiguity clarify rule: do NOT ask the user to confirm the window or threshold.
Just generate the proxy query directly using the DEFAULT thresholds named above (e.g. spend-drop = recent 90 days < 50% of prior 90 days; significantly past due = DUE_DATE more than 60 days before CURRENT_DATE). The answer layer states the proxy and its threshold so the user can see what was measured. Answering directly is the whole point - a predictive question that gets a clarifying question back feels broken.
DATA EBMS DOES NOT HAVE AT ALL - return exactly CANNOT_QUERY for these (there is no proxy):
  - Support tickets, complaints, customer service interactions, call counts (no CRM/ticketing module exists).
  - Future cash-position forecasts that require assumptions (30/60/90 day projections) - EBMS has actuals, not forecasts. (You MAY answer "who owes us money" / aged AR, which is factual.)
  - Subjective strategy questions ("if you were CEO", "what should I focus on") - no query answers these.

Rules you MUST follow:
1. ONLY generate SELECT statements - never INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, TRUNCATE, or any DDL/DML
2. Always double-quote the schema, table, AND every column name - all are case-sensitive uppercase: "{schema}"."TABLENAME" and "COLUMNNAME"
3. Example of correct query: SELECT "INVOICE", "INV_DATE", "NAME", "TOTAL", "BALANCE" FROM "companyname:legacy"."ARINV" ORDER BY "INV_DATE" DESC LIMIT 5
4. Always include LIMIT (max {max_rows}) unless the user explicitly wants totals/aggregates
5. Use ILIKE for case-insensitive string matching on text columns.
   For customer/vendor name searches, always split the name into individual keywords and match each one separately with OR.
   Example: "TIC parts service" → WHERE "L_NAME" ILIKE '%TIC%' OR "L_NAME" ILIKE '%T.I.C%' OR "L_NAME" ILIKE '%parts%' OR "L_NAME" ILIKE '%service%'
   Never rely on a single ILIKE pattern for name searches - names may have periods, ampersands, abbreviations, or extra words.
   If a name search returns 0 rows, add a fallback: search on just the most distinctive keyword (e.g. the least common word).
6. Return ONLY the SQL query - no explanation, no markdown, no code fences, no follow-up questions.
   If something is ambiguous, make the most reasonable assumption and generate the SQL anyway.
   Only ask a clarifying question if the query is genuinely impossible without more information (e.g. a specific date range the user must provide).
   MATERIAL-AMBIGUITY EXCEPTION (analytical questions only): if a question is analytical (profit, margin, "top"/"best"/"worst", spend trends, "last year")
   AND two reasonable interpretations would change the resulting number by more than ~10%, ASK one short clarifying question instead of guessing.
   To ask, return exactly: CANNOT_QUERY: <your one-line question>  (the app surfaces the text after CANNOT_QUERY as the answer).
   Examples that warrant asking: "top customers last year" (calendar vs fiscal year; by revenue vs by profit); "most profitable products" only if revenue-vs-profit ranking is unclear from context.
   Do NOT ask for simple lookups, or when the analytics recipes above already fix the method (e.g. plain "what is my gross margin" - the margin recipe is fixed, just answer it and the answer layer states the method). When unsure whether a fork is material, answer with the documented default rather than asking.
7. When joining tables, ALWAYS prefix every column with its table name to avoid ambiguity - even in SELECT and WHERE clauses.
8. For pagination or nth-row queries use OFFSET, never LIMIT x,y syntax. Example: second highest = ORDER BY ... DESC LIMIT 1 OFFSET 1
   Example: SELECT "ARCUST"."ID", "ARCUST"."L_NAME", "ARINV"."TOTAL" FROM "companyname:legacy"."ARCUST" JOIN "companyname:legacy"."ARINV" ON "ARCUST"."ID" = "ARINV"."ID"
   Never use bare column names like "ID" or "STATUS" when more than one table is in the query.

If the question cannot be answered with a read-only SQL query, return exactly: CANNOT_QUERY"""

# ---------------------------------------------------------------------------
# Session store
# ---------------------------------------------------------------------------

SESSION_TTL = 8 * 3600  # 8 hours of inactivity

_sessions: dict[str, dict] = {}
_sessions_lock = Lock()

def _create_session(username: str, full_name: str, permissions: dict, schema: str) -> str:
    token = secrets.token_urlsafe(32)
    now = time.time()
    with _sessions_lock:
        _sessions[token] = {
            "username": username,
            "full_name": full_name,
            "permissions": permissions,
            "schema": schema,
            "created_at": now,
            "last_seen": now,
        }
    return token

def _touch_session(token: str) -> dict | None:
    now = time.time()
    with _sessions_lock:
        sess = _sessions.get(token)
        if sess is None:
            return None
        if now - sess["last_seen"] > SESSION_TTL:
            del _sessions[token]
            return None
        sess["last_seen"] = now
        return dict(sess)

def _delete_session(token: str):
    with _sessions_lock:
        _sessions.pop(token, None)

# ---------------------------------------------------------------------------
# Permission helpers
# ---------------------------------------------------------------------------

MODULE_TABLES = {
    "GL": {"GLEDGER", "GLGLTRAN", "GLCTL"},
    "AR": {"ARINV", "ARINVDET", "ARCUST", "ARINVPMT", "ARINVPMTDET", "ARJRN", "ARSALESP", "ARQT"},
    "AP": {"APINV", "APINVDET", "APVENDOR"},
    "IN": {"INVENTRY", "INVENWH", "INTRAN"},
    "PY": {"PYTM", "PYTMDET", "PYEMP"},
    "JC": {"JCJB", "JCJBSTAT"},
}

# Map each table to the module that owns it
_TABLE_TO_MODULE: dict[str, str] = {
    tbl: mod for mod, tables in MODULE_TABLES.items() for tbl in tables
}

def get_user_permissions(username: str, schema: str | None = None) -> dict | None:
    """
    Query USERS table for the given username (already uppercased by caller).
    Returns a dict of module -> permission string, or None if user not found/inactive/deleted.
    """
    schema = schema or _default_schema()
    sql = f"""
        SELECT "FULL_NAME", "PASSWORD", "GL", "AP", "AR", "IN", "DP", "PY", "TA", "JC", "ES"
        FROM "{schema}"."USERS"
        WHERE "NAME" = %s
          AND "INACTIVE" = false
          AND "__deleted" = false
        LIMIT 1
    """
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, (username,))
                row = cur.fetchone()
    except psycopg.Error as e:
        log.error(f"Permission query failed: {e}")
        return None
    if row is None:
        return None
    row = dict(row)
    return row

def _strip_curr_id(sql: str) -> str:
    """Remove CURR_ID filter clauses from SQL for installs where the column doesn't exist."""
    import re
    # Remove AND/OR conditions referencing CURR_ID (handles IS NULL, =, <>, LIKE patterns)
    sql = re.sub(r'\s+AND\s*\([^)]*"CURR_ID"[^)]*\)', '', sql, flags=re.IGNORECASE)
    sql = re.sub(r'\s+OR\s*\([^)]*"CURR_ID"[^)]*\)', '', sql, flags=re.IGNORECASE)
    sql = re.sub(r'\s+AND\s+"CURR_ID"\s*[^\n,)]+', '', sql, flags=re.IGNORECASE)
    sql = re.sub(r',?\s*"CURR_ID"', '', sql, flags=re.IGNORECASE)
    return sql.strip()

def enforce_permissions(permissions: dict, sql: str):
    """Raise 403 if the SQL touches a table the user has No Access to."""
    # Extract quoted uppercase table names from the SQL
    tables_in_query = set(re.findall(r'"([A-Z][A-Z0-9_]+)"', sql))
    for table in tables_in_query:
        mod = _TABLE_TO_MODULE.get(table)
        if mod is None:
            continue
        perm = permissions.get(mod, "")
        if perm == "No Access":
            raise HTTPException(
                status_code=403,
                detail=f"You do not have access to the {mod} module."
            )

def is_password_weak(password: str) -> bool:
    if len(password) < 8:
        return True
    has_upper = any(c.isupper() for c in password)
    has_lower = any(c.islower() for c in password)
    has_digit = any(c.isdigit() for c in password)
    has_special = any(c in string.punctuation for c in password)
    return not (has_upper and has_lower and has_digit and has_special)

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

security = HTTPBearer()

def verify_session(credentials: HTTPAuthorizationCredentials = Security(security)) -> dict:
    sess = _touch_session(credentials.credentials)
    if sess is None:
        raise HTTPException(status_code=401, detail="Session expired or invalid. Please sign in again.")
    # Re-fetch permissions from DB on every request, using the schema bound to this session
    username = sess["username"]
    row = get_user_permissions(username, sess.get("schema"))
    if row is None:
        _delete_session(credentials.credentials)
        raise HTTPException(status_code=401, detail="User account no longer active.")
    sess["permissions"] = {k: row[k] for k in ("GL", "AP", "AR", "IN", "DP", "PY", "TA", "JC", "ES") if k in row}
    return sess


# ---------------------------------------------------------------------------
# Postgres connection
# ---------------------------------------------------------------------------

def get_conn():
    return psycopg.connect(
        host=PG_HOST,
        port=PG_PORT,
        dbname=PG_DB,
        user=PG_USER,
        password=PG_PASSWORD,
        connect_timeout=10,
        options=f"-c statement_timeout={SQL_TIMEOUT * 1000}",
        row_factory=dict_row,
    )

def _default_schema() -> str:
    """Return the first configured dataset's schema, or PG_SCHEMA as fallback."""
    return DATASETS[0]["schema"] if DATASETS else PG_SCHEMA

# ---------------------------------------------------------------------------
# Claude SQL generation
# ---------------------------------------------------------------------------

_claude = None

def get_claude():
    global _claude
    if _claude is None:
        _claude = anthropic.Anthropic(api_key=ANTHROPIC_KEY)
    return _claude

def fix_schema_quoting(sql: str) -> str:
    """Fix model occasionally quoting schema.TABLE as a single identifier instead of "schema"."TABLE"."""
    return re.sub(r'"([^"]+\.[A-Z_]+)"', lambda m: f'"{m.group(1).split(".", 1)[0]}"."{m.group(1).split(".", 1)[1]}"', sql)

def generate_sql(question: str, schema: str, history: list = None) -> tuple[str, str]:
    """Returns (sql, clarification) where clarification is any follow-up text the model appended."""
    prompt = SYSTEM_PROMPT.format(schema=schema, max_rows=MAX_ROWS)
    messages = []
    for h in (history or []):
        # Use SQL as assistant content so the model has unambiguous date/filter context
        content = (h.sql if h.role == "assistant" and h.sql else h.content)
        messages.append({"role": h.role, "content": content})
    messages.append({"role": "user", "content": question})
    msg = get_claude().messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=1024,
        system=prompt,
        messages=messages,
    )
    full_response = msg.content[0].text.strip()
    clarification = ""

    # If the model wrapped SQL in a code fence, extract SQL and capture anything after the fence
    fence_match = re.search(r"```(?:sql)?\s*\n(.*?)```(.*)", full_response, re.IGNORECASE | re.DOTALL)
    if fence_match:
        sql = fence_match.group(1).strip()
        clarification = fence_match.group(2).strip()
    else:
        sql = full_response
        # No fences - if model prefixed with explanation, extract from SELECT/WITH onward
        if not re.match(r"^\s*(SELECT|WITH|CANNOT_QUERY)\b", sql, re.IGNORECASE):
            sql_match = re.search(r"^\s*(SELECT|WITH)\b", sql, re.IGNORECASE | re.MULTILINE)
            if sql_match:
                clarification = sql[:sql_match.start()].strip()
                sql = sql[sql_match.start():].strip()
            else:
                # No SQL found at all - treat entire response as a clarification
                clarification = full_response
                sql = "CANNOT_QUERY"

    return sql.strip(), clarification

# ---------------------------------------------------------------------------
# Answer formatting
# ---------------------------------------------------------------------------

FORMAT_PROMPT = """You are a concise business assistant. The user asked a question about their EBMS ERP data.
You have the raw query results. Format a clear, helpful answer in plain English.
Use tables for multi-row results. Use dollar formatting for amounts. Be direct - no preamble.
If results are empty and the question involved a customer or vendor name, suggest the user may have used a different spelling or abbreviation (e.g. "T.I.C. Parts & Service" vs "TIC parts") and ask them to confirm the exact name.
If results are empty for any other reason, say so plainly and suggest why (e.g. no open invoices, date range issue).

EBMS STATUS codes - never mischaracterize these:
  'O' = outstanding (posted, unpaid invoice - money still owed)
  'X' = paid / closed (invoice has been paid - NOT cancelled, NOT voided)
  'U' = unprocessed (sales order not yet invoiced - never a real invoice)
When the SQL includes STATUS IN ('O','X') it means all posted invoices: both outstanding and paid.
When the SQL filters STATUS = 'O' only, it means unpaid/open invoices.

When showing balance totals (this MUST match how the SQL computed them - do not re-net the numbers yourself):
- A credit memo has a negative TOTAL. KEEP it in the total as a negative - it legitimately reduces what is owed. Do NOT drop it.
- A POSITIVE invoice with a negative BALANCE is an overpayment - it was already floored to $0 in the gross figure. Do not double-count it.
- So a grand total is: gross (positive invoices, overpayments floored to $0) PLUS credits (credit memos, kept negative) = net owing.
- When the result has both positive invoices and credit memos, present the three lines: Gross invoices $X / Credits applied -$Y / Net owing $Z.
- For a single customer or vendor, a plain net balance is fine - their own credits net against their own invoices.
- Never silently discard negative rows; a credit memo dropped from the total overstates what is owed.

ANALYTICAL ANSWERS (profit, margin, "most profitable", "dragging me down", spend trends, dead stock, late payers):
- These return a calculated number the user cannot eyeball-verify, so always make your method visible and correctable.
- End the answer with ONE plain-English methodology line stating what was measured and over what window, e.g.:
    "Gross margin = (net sales after line discounts - cost of goods) / net sales, on posted invoices this fiscal year. Excludes freight, handling, tax and header-level discounts."
    "Spend compared: last 90 days vs the prior 90 days, on posted invoices."
- Keep it to one line. The point is that the user can spot if your definition differs from their accountant's, not to write an essay.

PROXY ANSWERS (the user asked something predictive or judgemental - "likely to churn", "at risk", "will be late", "bad debt"):
- The data cannot predict; the SQL answered the closest FACTUAL signal instead. Be honest about this up front.
- LEAD with a one-line disclaimer naming the limit and what you measured instead, then give the real data. Example:
    "I can't predict which customers will stop buying, but here are customers whose spend dropped more than 50% in the last 90 days vs the prior 90 - a common early warning sign:"
- Never present a proxy as a prediction. No invented probabilities, scores, or "X% likely" figures - only what the data actually shows.

SANITY CHECK ON CALCULATED PERCENTAGES (flag impossible results - do NOT hide plausible ones):
- A gross margin % ABOVE 100, or any result computed from a NEGATIVE net-revenue figure, is mathematically impossible for a real margin and almost always signals a data issue (a bad join, or cost/credit-memo sign problem), NOT a real business result.
- There is NO lower bound on a real margin: a deep loss can be -150%, -300%, etc. (selling far below cost). Do NOT flag a large negative margin as impossible - it is a valid, if alarming, result. Only >100% and negative-net-revenue are truly impossible.
- When you see an impossible value, DO NOT report it as fact. Instead: state the figure, say plainly it isn't a possible real margin and likely reflects a data issue in how costs/credits are recorded, SHOW the raw underlying numbers (net sales and COGS), and advise verifying before relying on it.
    Example: "That comes out to 312%, which isn't possible for a real gross margin - it likely reflects a data issue in how costs are recorded on these invoices. Raw figures: net sales $X, cost of goods $Y. Worth checking the cost data before relying on this."
- This applies ONLY to mathematically-impossible values. Normal-but-surprising results (a thin 3% margin, a real -12% loss, even a real -200% loss on items dumped below cost) are valid answers - report them normally. NEVER suppress or cast doubt on a plausible number just because it is bad news.

COST-DATA COVERAGE REFUSAL (when the margin query returns a coverage ratio below 0.80):
- The margin recipe gates on cost-data coverage. If the query reports coverage < 80% (most revenue has no recorded cost), DO NOT state a margin %.
- Instead, refuse honestly and explain the gap, then offer what you CAN show. Be specific about the coverage figure if available.
    Example: "I can't give you a reliable gross margin - cost is recorded on only about {coverage}% of your sales, so any margin figure would be badly overstated (uncosted lines look like 100% profit). Your EBMS Product Profit report has the same blind spot for the same reason. To get a real margin, item costs need to be maintained at the time of sale. In the meantime I can show revenue, top products by sales, top customers, or AR - just ask."
- Frame this as IntraMind catching a data-quality issue, not as a limitation of IntraMind. It is a trust signal, not a failure."""

def format_answer(question: str, rows: list[dict], sql: str, history: list = None) -> str:
    if not rows:
        data_str = "Query returned 0 rows."
    else:
        data_str = json.dumps(rows[:50], default=str, indent=2)  # cap for context

    messages = []
    for h in (history or []):
        messages.append({"role": h.role, "content": h.content})
    messages.append({
        "role": "user",
        "content": f"Question: {question}\n\nSQL used: {sql}\n\nResults ({len(rows)} rows):\n{data_str}"
    })
    msg = get_claude().messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=2048,
        system=FORMAT_PROMPT,
        messages=messages,
    )
    return msg.content[0].text.strip()

# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

class LoginRequest(BaseModel):
    username: str
    password: str
    dataset: str = ""  # schema string of the chosen dataset; empty = use first/default

class HistoryMessage(BaseModel):
    role: str     # "user" or "assistant"
    content: str  # English answer (used by format_answer for context)
    sql: str = "" # SQL query (used by generate_sql for context -- unambiguous for date/filter references)

class QueryRequest(BaseModel):
    question: str
    history: list[HistoryMessage] = []

class QueryResponse(BaseModel):
    answer: str
    sql: str
    row_count: int
    db_schema: str

# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info(f"EBMS Live Query Agent starting - schema default: {PG_SCHEMA}, port: {PORT}")
    # Verify DB connection on startup
    try:
        conn = get_conn()
        conn.close()
        log.info("Postgres connection OK")
    except Exception as e:
        log.error(f"Postgres connection FAILED: {e}")
    yield

app = FastAPI(title="EBMS Live Query Agent", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://intramind.ca", "http://localhost:5173", "http://localhost:3000"],
    allow_methods=["POST", "GET"],
    allow_headers=["Authorization", "Content-Type"],
)

@app.get("/", response_class=HTMLResponse)
def ui():
    html_path = Path(__file__).parent / "ui.html"
    return html_path.read_text(encoding="utf-8")

@app.get("/health")
def health():
    return {"status": "ok", "schema": PG_SCHEMA, "company": COMPANY_NAME, "version": VERSION}

@app.get("/whats-new")
def whats_new():
    """Return whats_new for current version if a pending update notification exists."""
    pending_path = Path(r"C:\ProgramData\IntraMind\pending_update.txt")
    try:
        pending = json.loads(pending_path.read_text(encoding="utf-8").strip())
    except (OSError, json.JSONDecodeError):
        return {"version": VERSION, "changelog": None}
    pending_version = (pending.get("version") or "").split("-")[0]
    if pending_version != VERSION:
        return {"version": VERSION, "changelog": None}
    changelog = pending.get("whats_new") or None
    return {"version": VERSION, "changelog": changelog}

@app.get("/datasets")
def datasets_list():
    """Return available datasets for the login screen dropdown."""
    return {"datasets": [{"name": d["name"], "schema": d["schema"]} for d in DATASETS]}

@app.post("/login")
def login(req: LoginRequest):
    username_upper = req.username.strip().upper()

    # Resolve and validate the requested dataset schema
    requested_schema = req.dataset.strip()
    if requested_schema:
        if requested_schema not in DATASET_SCHEMAS:
            raise HTTPException(status_code=400, detail="Invalid dataset selection.")
        chosen_schema = requested_schema
    else:
        chosen_schema = _default_schema()

    # Free tier: only the INTRAMIND user is accepted
    if EBMS_LIVE_TIER == "free" and username_upper != "INTRAMIND":
        secrets.compare_digest(req.password.encode(), b"x")
        raise HTTPException(status_code=401, detail="Invalid username or password.")

    row = get_user_permissions(username_upper, chosen_schema)

    # Always do a constant-time compare even when user not found (prevents username enumeration)
    stored_password = row["PASSWORD"] if (row and row.get("PASSWORD")) else ""
    # FoxPro stores passwords with each ASCII byte offset by +128, then migrated to Postgres as
    # UTF-8 Latin-1. Encode the input the same way for comparison.
    input_encoded = bytes(ord(c) + 0x80 for c in req.password)
    stored_encoded = stored_password.encode("latin-1")
    password_match = secrets.compare_digest(input_encoded, stored_encoded)

    if row is None or not stored_password or not password_match:
        raise HTTPException(status_code=401, detail="Invalid username or password.")

    permissions = {k: row[k] for k in ("GL", "AP", "AR", "IN", "DP", "PY", "TA", "JC", "ES") if k in row}
    full_name = row.get("FULL_NAME") or username_upper
    session_token = _create_session(username_upper, full_name, permissions, chosen_schema)

    password_weak = is_password_weak(req.password)

    log.info(f"Login: {username_upper} schema={chosen_schema} (tier={EBMS_LIVE_TIER})")
    return {
        "token": session_token,
        "full_name": full_name,
        "username": username_upper,
        "schema": chosen_schema,
        "password_weak": password_weak,
        "tier": EBMS_LIVE_TIER,
    }

@app.post("/logout")
def logout(credentials: HTTPAuthorizationCredentials = Security(security)):
    _delete_session(credentials.credentials)
    return {"ok": True}

@app.get("/company")
def company_info(sess: dict = Depends(verify_session)):
    """Return company name from GLCTL for the session's schema."""
    s = (sess.get("schema") or _default_schema()).strip()
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(f'SELECT "NAME" FROM "{s}"."GLCTL" LIMIT 1')
                row = cur.fetchone()
                name = row["NAME"].strip() if row and row.get("NAME") else COMPANY_NAME
    except Exception:
        name = COMPANY_NAME
    return {"company": name}

@app.get("/kpis")
def kpis(sess: dict = Depends(verify_session)):
    """Return 8 dashboard KPIs as structured numbers - no Claude involved."""
    s = (sess.get("schema") or _default_schema()).strip()
    queries = {
        # Net AR = sum of positive balances + sum of credit memo balances
        "ar_outstanding": f"""
            SELECT
                COALESCE(SUM(GREATEST("{s}"."ARINV"."BALANCE", 0)), 0)
                + COALESCE(SUM(CASE WHEN "{s}"."ARINV"."TOTAL" < 0 THEN "{s}"."ARINV"."BALANCE" ELSE 0 END), 0)
                AS val,
                COUNT(CASE WHEN "{s}"."ARINV"."TOTAL" > 0 THEN 1 END) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'O'
        """,
        "sales_this_month": f"""
            SELECT COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS val,
                   COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
              AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
              AND "{s}"."ARINV"."INV_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."TOTAL" > 0
        """,
        "sales_last_month": f"""
            SELECT COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS val,
                   COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
              AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE - INTERVAL '1 month')
              AND "{s}"."ARINV"."INV_DATE" < DATE_TRUNC('month', CURRENT_DATE)
              AND "{s}"."ARINV"."TOTAL" > 0
        """,
        # Net overdue = positive balances + credits on overdue invoices
        "overdue": f"""
            SELECT
                COALESCE(SUM(GREATEST("{s}"."ARINV"."BALANCE", 0)), 0)
                + COALESCE(SUM(CASE WHEN "{s}"."ARINV"."TOTAL" < 0 THEN "{s}"."ARINV"."BALANCE" ELSE 0 END), 0)
                AS val,
                COUNT(CASE WHEN "{s}"."ARINV"."TOTAL" > 0 THEN 1 END) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'O'
              AND "{s}"."ARINV"."DUE_DATE" < CURRENT_DATE
        """,
        # Net AP = sum of positive balances + sum of credit memo balances
        "ap_outstanding": f"""
            SELECT
                COALESCE(SUM(GREATEST("{s}"."APINV"."BALANCE", 0)), 0)
                + COALESCE(SUM(CASE WHEN "{s}"."APINV"."TOTAL" < 0 THEN "{s}"."APINV"."BALANCE" ELSE 0 END), 0)
                AS val,
                COUNT(CASE WHEN "{s}"."APINV"."TOTAL" > 0 THEN 1 END) AS cnt
            FROM "{s}"."APINV"
            WHERE "{s}"."APINV"."STATUS" = 'O'
        """,
        "bills_due_week": f"""
            SELECT
                COALESCE(SUM(GREATEST("{s}"."APINV"."BALANCE", 0)), 0) AS val,
                COUNT(CASE WHEN "{s}"."APINV"."TOTAL" > 0 THEN 1 END) AS cnt
            FROM "{s}"."APINV"
            WHERE "{s}"."APINV"."STATUS" = 'O'
              AND "{s}"."APINV"."DUE_DATE" >= CURRENT_DATE
              AND "{s}"."APINV"."DUE_DATE" <= CURRENT_DATE + INTERVAL '7 days'
              AND "{s}"."APINV"."TOTAL" > 0
        """,
        "payroll_this_month": f"""
            SELECT
                COALESCE(SUM("{s}"."PYTM"."G_PAY"), 0) AS val,
                COUNT(*) AS cnt
            FROM "{s}"."PYTM"
            WHERE "{s}"."PYTM"."PAY_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
              AND "{s}"."PYTM"."PAY_DATE" <= CURRENT_DATE
              AND "{s}"."PYTM"."G_PAY" > 0
        """,
        "payments_received": f"""
            SELECT
                COALESCE(SUM("{s}"."ARINVPMT"."AMOUNT"), 0) AS val,
                COUNT(*) AS cnt
            FROM "{s}"."ARINVPMT"
            WHERE "{s}"."ARINVPMT"."DATE" >= DATE_TRUNC('month', CURRENT_DATE)
              AND "{s}"."ARINVPMT"."DATE" <= CURRENT_DATE
              AND "{s}"."ARINVPMT"."AMOUNT" > 0
              AND "{s}"."ARINVPMT"."STATUS" <> 4
        """,
        "avg_days_to_pay": f"""
            SELECT
                COALESCE(AVG(
                    "{s}"."ARINV"."CLOSE_DATE"::date - "{s}"."ARINV"."INV_DATE"::date
                ), 0) AS val,
                COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'X'
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."CLOSE_DATE" >= '2000-01-01'
              AND "{s}"."ARINV"."CLOSE_DATE" >= DATE_TRUNC('year', CURRENT_DATE)
              AND "{s}"."ARINV"."CLOSE_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."INV_DATE" IS NOT NULL
              AND "{s}"."ARINV"."CLOSE_DATE" > "{s}"."ARINV"."INV_DATE"
        """,
    }
    result = {}
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                for key, sql in queries.items():
                    try:
                        cur.execute(sql)
                        row = dict(cur.fetchone())
                        result[key] = {"value": float(row["val"]), "count": int(row["cnt"])}
                    except Exception as e:
                        log.warning(f"KPI query failed for {key}: {e}")
                        result[key] = {"value": None, "count": None}
    except psycopg.Error as e:
        log.error(f"KPI connection error: {e}")
        raise HTTPException(status_code=503, detail="Database unavailable")
    return result

@app.get("/kpis/detail/{key}")
def kpi_detail(key: str, sess: dict = Depends(verify_session)):
    """Return drill-down rows + verified summary for a KPI card. No Claude involved."""
    s = (sess.get("schema") or _default_schema()).strip()

    detail_queries = {
        "ar_outstanding": {
            "title": "Outstanding Customer Invoices",
            "rows_sql": f"""
                SELECT
                    "{s}"."ARINV"."INVOICE" AS invoice,
                    "{s}"."ARINV"."INV_DATE" AS date,
                    "{s}"."ARINV"."NAME" AS customer,
                    "{s}"."ARINV"."TOTAL" AS total,
                    "{s}"."ARINV"."BALANCE" AS balance,
                    CASE WHEN "{s}"."ARINV"."TOTAL" < 0 THEN 'credit'
                         WHEN "{s}"."ARINV"."BALANCE" < 0 THEN 'overpaid'
                         ELSE 'invoice' END AS row_type
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" = 'O'
                ORDER BY "{s}"."ARINV"."INV_DATE" DESC
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM(GREATEST("{s}"."ARINV"."BALANCE", 0)) FILTER (WHERE "{s}"."ARINV"."TOTAL" > 0), 0) AS gross,
                    COALESCE(SUM("{s}"."ARINV"."BALANCE") FILTER (WHERE "{s}"."ARINV"."TOTAL" < 0), 0) AS credits
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" = 'O'
            """,
        },
        "ap_outstanding": {
            "title": "Outstanding Vendor Bills",
            "rows_sql": f"""
                SELECT
                    "{s}"."APINV"."INVOICE" AS invoice,
                    "{s}"."APINV"."INV_DATE" AS date,
                    "{s}"."APINV"."NAME" AS vendor,
                    "{s}"."APINV"."TOTAL" AS total,
                    "{s}"."APINV"."BALANCE" AS balance,
                    CASE WHEN "{s}"."APINV"."TOTAL" < 0 THEN 'credit'
                         WHEN "{s}"."APINV"."BALANCE" < 0 THEN 'overpaid'
                         ELSE 'invoice' END AS row_type
                FROM "{s}"."APINV"
                WHERE "{s}"."APINV"."STATUS" = 'O'
                ORDER BY "{s}"."APINV"."INV_DATE" DESC
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM(GREATEST("{s}"."APINV"."BALANCE", 0)) FILTER (WHERE "{s}"."APINV"."TOTAL" > 0), 0) AS gross,
                    COALESCE(SUM("{s}"."APINV"."BALANCE") FILTER (WHERE "{s}"."APINV"."TOTAL" < 0), 0) AS credits
                FROM "{s}"."APINV"
                WHERE "{s}"."APINV"."STATUS" = 'O'
            """,
        },
        "overdue": {
            "title": "Overdue AR Invoices",
            "rows_sql": f"""
                SELECT
                    "{s}"."ARINV"."INVOICE" AS invoice,
                    "{s}"."ARINV"."DUE_DATE" AS due_date,
                    "{s}"."ARINV"."NAME" AS customer,
                    "{s}"."ARINV"."TOTAL" AS total,
                    "{s}"."ARINV"."BALANCE" AS balance,
                    CASE WHEN "{s}"."ARINV"."TOTAL" < 0 THEN 'credit'
                         WHEN "{s}"."ARINV"."BALANCE" < 0 THEN 'overpaid'
                         ELSE 'invoice' END AS row_type
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" = 'O'
                  AND "{s}"."ARINV"."DUE_DATE" < CURRENT_DATE
                ORDER BY "{s}"."ARINV"."DUE_DATE" ASC
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM(GREATEST("{s}"."ARINV"."BALANCE", 0)) FILTER (WHERE "{s}"."ARINV"."TOTAL" > 0), 0) AS gross,
                    COALESCE(SUM("{s}"."ARINV"."BALANCE") FILTER (WHERE "{s}"."ARINV"."TOTAL" < 0), 0) AS credits
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" = 'O'
                  AND "{s}"."ARINV"."DUE_DATE" < CURRENT_DATE
            """,
        },
    }

    # Days to pay uses a different query/response shape
    if key == "days_to_pay":
        rows_sql = f"""
            SELECT
                "{s}"."ARCUST"."L_NAME" AS customer,
                COUNT(*) AS invoices_paid,
                ROUND(AVG(
                    "{s}"."ARINV"."CLOSE_DATE"::date - "{s}"."ARINV"."INV_DATE"::date
                )) AS avg_days
            FROM "{s}"."ARINV"
            JOIN "{s}"."ARCUST" ON "{s}"."ARCUST"."ID" = "{s}"."ARINV"."ID"
            WHERE "{s}"."ARINV"."STATUS" = 'X'
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."CLOSE_DATE" >= '2000-01-01'
              AND "{s}"."ARINV"."CLOSE_DATE" >= DATE_TRUNC('year', CURRENT_DATE)
              AND "{s}"."ARINV"."CLOSE_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."INV_DATE" IS NOT NULL
              AND "{s}"."ARINV"."CLOSE_DATE" > "{s}"."ARINV"."INV_DATE"
            GROUP BY "{s}"."ARCUST"."L_NAME"
            ORDER BY avg_days DESC
            LIMIT 100
        """
        summary_sql = f"""
            SELECT
                ROUND(AVG(
                    "{s}"."ARINV"."CLOSE_DATE"::date - "{s}"."ARINV"."INV_DATE"::date
                )) AS avg_days,
                COUNT(*) AS total_invoices
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'X'
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."CLOSE_DATE" >= '2000-01-01'
              AND "{s}"."ARINV"."CLOSE_DATE" >= DATE_TRUNC('year', CURRENT_DATE)
              AND "{s}"."ARINV"."CLOSE_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."INV_DATE" IS NOT NULL
              AND "{s}"."ARINV"."CLOSE_DATE" > "{s}"."ARINV"."INV_DATE"
        """
        try:
            with get_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(rows_sql)
                    rows = [dict(r) for r in cur.fetchall()]
                    cur.execute(summary_sql)
                    summary_row = dict(cur.fetchone())
        except psycopg.Error as e:
            log.error(f"KPI detail query error for days_to_pay: {e}")
            raise HTTPException(status_code=503, detail="Database unavailable")
        return {
            "title": "Average Days to Payment (This Year)",
            "rows": rows,
            "summary": {
                "avg_days": int(summary_row["avg_days"] or 0),
                "total_invoices": int(summary_row["total_invoices"] or 0),
                "type": "days_to_pay",
            },
        }

    if key not in detail_queries:
        raise HTTPException(status_code=404, detail=f"Unknown KPI key: {key}")

    q = detail_queries[key]
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(q["rows_sql"])
                rows = [dict(r) for r in cur.fetchall()]
                cur.execute(q["summary_sql"])
                summary_row = dict(cur.fetchone())
    except psycopg.Error as e:
        log.error(f"KPI detail query error: {e}")
        raise HTTPException(status_code=503, detail="Database unavailable")

    gross = float(summary_row["gross"])
    credits = float(summary_row["credits"])
    net = gross + credits

    return {
        "title": q["title"],
        "rows": rows,
        "summary": {"gross": gross, "credits": credits, "net": net},
    }

@app.get("/charts")
def charts(sess: dict = Depends(verify_session)):
    """Return chart datasets - all deterministic SQL, no Claude involved."""
    s = (sess.get("schema") or _default_schema()).strip()

    chart_queries = {
        "ar_aging": f"""
            SELECT
                CASE
                    WHEN CURRENT_DATE - "{s}"."ARINV"."DUE_DATE" <= 30 THEN '0-30'
                    WHEN CURRENT_DATE - "{s}"."ARINV"."DUE_DATE" <= 60 THEN '31-60'
                    WHEN CURRENT_DATE - "{s}"."ARINV"."DUE_DATE" <= 90 THEN '61-90'
                    ELSE '90+'
                END AS bucket,
                COALESCE(SUM(GREATEST("{s}"."ARINV"."BALANCE", 0)), 0) AS amount,
                COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'O'
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."DUE_DATE" < CURRENT_DATE
            GROUP BY bucket
            ORDER BY MIN(CURRENT_DATE - "{s}"."ARINV"."DUE_DATE")
        """,
        "sales_by_month": f"""
            SELECT
                TO_CHAR(DATE_TRUNC('month', "{s}"."ARINV"."INV_DATE"), 'Mon YY') AS month,
                DATE_TRUNC('month', "{s}"."ARINV"."INV_DATE") AS month_start,
                COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS amount,
                COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
              AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE - INTERVAL '5 months')
              AND "{s}"."ARINV"."INV_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."TOTAL" > 0
            GROUP BY DATE_TRUNC('month', "{s}"."ARINV"."INV_DATE"),
                     TO_CHAR(DATE_TRUNC('month', "{s}"."ARINV"."INV_DATE"), 'Mon YY')
            ORDER BY month_start
        """,
        "top_customers": f"""
            SELECT
                "{s}"."ARINV"."NAME" AS name,
                COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS amount
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
              AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('year', CURRENT_DATE)
              AND "{s}"."ARINV"."INV_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."TOTAL" > 0
            GROUP BY "{s}"."ARINV"."NAME"
            ORDER BY amount DESC
            LIMIT 10
        """,
        "ap_aging": f"""
            SELECT
                CASE
                    WHEN CURRENT_DATE - "{s}"."APINV"."DUE_DATE" <= 30 THEN '0-30'
                    WHEN CURRENT_DATE - "{s}"."APINV"."DUE_DATE" <= 60 THEN '31-60'
                    WHEN CURRENT_DATE - "{s}"."APINV"."DUE_DATE" <= 90 THEN '61-90'
                    ELSE '90+'
                END AS bucket,
                COALESCE(SUM(GREATEST("{s}"."APINV"."BALANCE", 0)), 0) AS amount,
                COUNT(*) AS cnt
            FROM "{s}"."APINV"
            WHERE "{s}"."APINV"."STATUS" = 'O'
              AND "{s}"."APINV"."TOTAL" > 0
              AND "{s}"."APINV"."DUE_DATE" < CURRENT_DATE
            GROUP BY bucket
            ORDER BY MIN(CURRENT_DATE - "{s}"."APINV"."DUE_DATE")
        """,
    }

    result = {}
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                for key, sql in chart_queries.items():
                    try:
                        cur.execute(sql)
                        rows = [dict(r) for r in cur.fetchall()]
                        # Drop month_start helper column from sales_by_month
                        if key == "sales_by_month":
                            rows = [{k: v for k, v in r.items() if k != "month_start"} for r in rows]
                        # Coerce numeric fields to float
                        for row in rows:
                            for k, v in row.items():
                                if isinstance(v, (int, float)) or (hasattr(v, '__float__') and k in ('amount',)):
                                    try:
                                        row[k] = float(v)
                                    except (TypeError, ValueError):
                                        pass
                        result[key] = rows
                    except Exception as e:
                        log.warning(f"Chart query failed for {key}: {e}")
                        result[key] = None
    except psycopg.Error as e:
        log.error(f"Charts connection error: {e}")
        raise HTTPException(status_code=503, detail="Database unavailable")

    return result

@app.post("/query", response_model=QueryResponse)
def query(req: QueryRequest, request: Request, sess: dict = Depends(verify_session)):
    check_rate_limit(request.client.host)

    question = req.question.strip()
    schema = sess.get("schema") or _default_schema()

    if not question:
        raise HTTPException(status_code=400, detail="Question cannot be empty")

    # Generate SQL (pass conversation history for context-aware follow-up questions)
    sql, clarification = generate_sql(question, schema, req.history)
    sql = fix_schema_quoting(sql)
    log.info(f"Generated SQL: {sql[:200]}")

    if sql.startswith("CANNOT_QUERY"):
        # Model may append an explanation after CANNOT_QUERY - extract it
        explanation = sql[len("CANNOT_QUERY"):].strip(" \n:-")
        answer = explanation if explanation else "I can only answer questions that can be looked up in the EBMS database. Try asking about invoices, customers, inventory, or job status."
        return QueryResponse(
            answer=answer,
            sql="",
            row_count=0,
            db_schema=schema,
        )

    # Safety check - allow SELECT and WITH (CTEs), reject everything else
    if not re.match(r"^\s*(SELECT|WITH)\b", sql, re.IGNORECASE):
        log.warning(f"Rejected non-SELECT SQL: {sql[:100]}")
        log_query_error(question, sql, "", "rejected: not a SELECT")
        raise HTTPException(status_code=400, detail="Generated query was not a SELECT - rejected for safety.")
    # Secondary check - must not contain any write keywords
    if re.search(r"\b(INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|TRUNCATE|GRANT|REVOKE)\b", sql, re.IGNORECASE):
        log.warning(f"Rejected SQL with write keyword: {sql[:100]}")
        log_query_error(question, sql, "", "rejected: write keyword")
        raise HTTPException(status_code=400, detail="Generated query contained disallowed keywords - rejected for safety.")

    # Permission enforcement - block queries touching modules user has No Access to
    enforce_permissions(sess["permissions"], sql)

    # Execute
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                try:
                    cur.execute(sql)
                    rows = [dict(r) for r in cur.fetchmany(MAX_ROWS)]
                except psycopg.Error as e:
                    err = str(e)
                    # If a generated currency column doesn't exist on this install, strip it and retry
                    if "does not exist" in err and "CURR_ID" in err:
                        conn.rollback()
                        sql = _strip_curr_id(sql)
                        cur.execute(sql)
                        rows = [dict(r) for r in cur.fetchmany(MAX_ROWS)]
                        log.warning(f"CURR_ID not present -- retried query without currency filter")
                    else:
                        raise
    except psycopg.Error as e:
        log.error(f"Query error: {e}")
        log_query_error(question, sql, "", str(e))
        # Implicit negative feedback: failed queries surface in the portal feed
        append_feedback({
            "rating": "error",
            "category": "query_failed",
            "comment": str(e)[:500],
            "question": question[:1000],
            "sql": sql[:2000] if sql else "",
            "answer": "",
            "username": sess.get("username", ""),
            "schema": sess.get("schema", ""),
        })
        raise HTTPException(status_code=422, detail=f"Query failed: {str(e)}")

    # Format answer (pass history so follow-up context is available)
    answer = format_answer(question, rows, sql, req.history)

    # Append any clarifying question the model asked after the SQL
    if clarification:
        answer = f"{answer}\n\n{clarification}"

    record_query(sess["username"])

    return QueryResponse(answer=answer, sql=sql, row_count=len(rows), db_schema=schema)


def _verify_portal_token(request: Request):
    token = request.headers.get("X-Portal-Token", "")
    if not PORTAL_TOKEN or not secrets.compare_digest(token, PORTAL_TOKEN):
        raise HTTPException(status_code=401, detail="Invalid portal token.")

# ---------------------------------------------------------------------------
# Query feedback
# ---------------------------------------------------------------------------

_FEEDBACK_PATHS = [
    Path(r"C:\ProgramData\IntraMind\feedback.jsonl"),
    Path(__file__).parent / "feedback.jsonl",
]

def append_feedback(entry: dict):
    entry["time"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    entry["version"] = VERSION
    line = json.dumps(entry, ensure_ascii=False)
    for p in _FEEDBACK_PATHS:
        try:
            with open(p, "a", encoding="utf-8") as f:
                f.write(line + "\n")
            return
        except OSError:
            continue
    log.warning("Could not write feedback entry to any path")

class FeedbackRequest(BaseModel):
    rating: str            # "up" or "down"
    question: str = ""
    sql: str = ""
    answer: str = ""
    category: str = ""
    comment: str = ""

@app.post("/feedback")
def submit_feedback(req: FeedbackRequest, sess: dict = Depends(verify_session)):
    """Record user feedback on a query answer."""
    if req.rating not in ("up", "down"):
        raise HTTPException(status_code=400, detail="rating must be 'up' or 'down'")
    append_feedback({
        "rating": req.rating,
        "category": req.category[:50],
        "comment": req.comment[:1000],
        "question": req.question[:1000],
        "sql": req.sql[:2000],
        "answer": req.answer[:2000],
        "username": sess.get("username", ""),
        "schema": sess.get("schema", ""),
    })
    return {"ok": True}

@app.get("/feedback")
def get_feedback(request: Request, limit: int = 200):
    """Return recent feedback entries for the admin portal. Protected by X-Portal-Token header."""
    _verify_portal_token(request)
    limit = min(max(limit, 10), 500)
    for p in _FEEDBACK_PATHS:
        try:
            lines = p.read_text(encoding="utf-8").splitlines()
        except OSError:
            continue
        entries = []
        for line in lines[-limit:]:
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        entries.reverse()  # newest first
        return {"entries": entries, "total": len(lines)}
    return {"entries": [], "total": 0}

@app.get("/stats")
def stats(request: Request):
    """Usage stats for the IntraMind admin portal. Protected by X-Portal-Token header."""
    _verify_portal_token(request)
    return get_stats_snapshot()

@app.get("/logs")
def logs(request: Request, lines: int = 200):
    """Return last N lines of agent.log for the admin portal. Protected by X-Portal-Token header."""
    _verify_portal_token(request)
    lines = min(max(lines, 10), 500)
    log_paths = [
        Path(r"C:\ProgramData\IntraMind\agent.log"),
        Path(__file__).parent / "agent.log",
    ]
    for p in log_paths:
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
            tail = text.splitlines()[-lines:]
            return {"lines": tail, "path": str(p), "total_lines": len(text.splitlines())}
        except OSError:
            pass
    return {"lines": [], "path": None, "total_lines": 0}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("ebms_live.server:app", host="0.0.0.0", port=PORT, reload=False)
