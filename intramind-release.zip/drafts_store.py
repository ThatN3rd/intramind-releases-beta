"""Drafts and the write audit log: storage for v3 Phase 4 (ClickUp 86e3q4zc9, PO 86e3q4ze6).

Contract: docs/design/v3-drafts-contract.md. Spec: docs/design/intramind-redesign-spec.md
sections 5 (Phase 4), 8.9, 8.10 and 11.

Pure module, same rules as pins_store.py: no FastAPI, no psycopg, no EBMS connection, and it
does NOT import server.py. It owns IntraMind's own drafts file (SQLite, never EBMS's Postgres).

STORAGE
  File: EBMS_LIVE_DRAFTS_DB if set, else C:\\ProgramData\\IntraMind\\drafts.sqlite3 when that
  directory exists (production), else <this file's dir>/drafts.sqlite3 (dev only). One file holds
  both tables (drafts + audit) so a save's status change and its audit row commit in ONE
  transaction; a separate audit file could record a save that never happened, or miss one.
  One connection per call, WAL, 5 s busy timeout, PRAGMA user_version migrations.

AUDIT IS APPEND-ONLY, KEPT ONE YEAR
  This module never issues UPDATE against `audit`; its only DELETE is purge_audit() (tests/
  test_drafts_store.py greps for both). The schema adds a BEFORE UPDATE trigger that always aborts
  and a BEFORE DELETE trigger that aborts for rows younger than one year (AUDIT_RETENTION_DAYS), so
  even a hand-written statement can't rewrite history or drop recent rows.

USERNAMES / SCHEMAS
  username .strip().upper() (same as server.py login() and pins_store); schema whitespace-trimmed,
  compared exactly. Every draft read/write is scoped to (username, schema): someone else's draft
  is indistinguishable from a missing one (the routes answer 404 for both).

STATUS MACHINE (optimistic: every transition checks the current status inside BEGIN IMMEDIATE)
  draft  --update-->  draft            (also failed --update--> draft)
  draft|failed --claim_save--> saving --mark_saved--> saved --mark_undone--> draft
                                      --mark_failed--> failed
  draft|failed --recover_saved--> saved (EBMS already has the document found by the cycle's key)
  draft|failed --discard--> discarded --restore--> draft
  draft|failed|reading --clear_drafts--> discarded      (one transaction; 'saving' never cleared)
  saved --clear_drafts(include_saved=True)--> discarded (simulated-EBMS reset only; keeps the EBMS fields)
  saving --fail_interrupted_saves (startup)--> failed   (idempotency key kept; imports: fail_interrupted_imports)

IDEMPOTENCY (spec 11.5)
  The browser sends an idempotency key with Save. Every key is kept in `idem_keys` (key ->
  draft) until its draft is purged (90 days after the draft's last update), so a replayed request (double-click, network retry, a stale tab after Undo)
  never starts a second save. drafts.idempotency_key is the key sent to EBMS for the CURRENT
  save cycle (it becomes EXTERNALID on the EBMS document): it is set by the first claim, kept
  across failed retries (so a retry after a timeout finds the document the timed-out call may
  have created instead of creating another one), and cleared by Undo (the next save is a new
  document). It is UNIQUE, nullable.

UPLOADED DOCUMENTS (vendor bills, ClickUp 86e3q4zeb)
  The original bytes of an uploaded bill (PDF or photo) live in the `documents` table of this
  same file, one row per draft, keyed by draft id and carrying the owner (username, schema):
  get_document() only returns a row to its owner, like every draft read. They are kept for
  at most DOCUMENT_RETENTION_DAYS (30) from upload (the Settings choice may be shorter), then
  purged by the daily purge_all() run (and at startup), within about a day of the limit. Drafts, with their documents and
  idempotency keys, are purged 90 days after their last update (purge_drafts; a draft in
  'saving' or 'reading' is skipped). Until then the draft and its card survive the document
  purge; only the "View PDF" bytes go. Documents are not audit rows: purging them never touches `audit`.

REVIEW LIST AND BACKGROUND READING (86e3q4ze8)
  review_state: 'needs_review' for drafts made from an uploaded document or plain text,
  'reviewed' once opened, edited or saved. A document dropped in the background first lands as
  a placeholder (type 'doc', status 'reading', its file stored); the reader then fills it
  (fill_draft -> status 'draft') or fails it (fail_reading -> 'failed' with a human `detail`).
  Reading jobs live in server memory, so at startup fail_interrupted() turns any leftover
  'reading' draft into a failed one. Open drafts list needs_review / reading first, then newest.

DUPLICATES AND CLEARING (batch 2)
  find_bill_conflict(): another user's (or the same user's) saved/saving bill for the same vendor
  and invoice number in this dataset; any other saving draft counts, except a stale one
  (STALE_SAVING_SECONDS); startup fail_interrupted_saves() fails drafts left saving by a restart.
  find_open_by_sha(): this user's open draft with an identical upload. clear_drafts(): discards a user's Review list (and
  optionally saved drafts) in one transaction, deleting their stored uploads; audit rows are only
  added (purge_audit removes them after a year); 'saving' drafts are never cleared.
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

AUDIT_RETENTION_DAYS = 365
DRAFT_RETENTION_DAYS = 90
SCHEMA_VERSION = 6  # 2: documents table (86e3q4zeb); 3: review_state + detail (86e3q4ze8); 4: user_settings; 5: company_settings; 6: audit rows deletable after one year, and audit.api_user added when missing (vpa6m)
BUSY_TIMEOUT_SECONDS = 5.0
# A save stuck in 'saving' this long (process killed mid-call) may be claimed again. The retry
# reuses the same EBMS key, so the client's EXTERNALID lookup finds anything the dead call made.
# It must stay well above the client's worst case for one create (ebms_api.max_create_seconds(),
# 389 s with a 55 s timeout and 2 GET retries; httpx applies the timeout per phase, so a single
# request can run longer), or a second claim could POST while the first call is still in flight
# (86e3q4zc9 review #4). tests/test_drafts_store.py pins STALE >= 3 x that worst case. A sales
# order save can also create up to MAX_NEW_RECORDS new customers/parts first (86e3q4ze8), one
# create each, so the window covers (1 + MAX_NEW_RECORDS) creates with the same 3x margin.
# A bill save also asks EBMS, before anything is sent, for the same vendor and invoice number
# (vpa5k): at least 2 GETs (the read ends on an empty page) and up to BILL_DUP_MAX_PAGES = 10, each
# a retried GET of ebms_api.max_retried_call_seconds() = 167 s. The largest bill save (5 new
# records, 6 creates at 389 s = 2,334 s) is about 2,670 s worst case at 2 GETs (7,200 s is 2.7x)
# and about 4,000 s at 10 GETs (1.8x). The pinned STALE >= 3 x max_create_seconds()
# (tests/test_drafts_store.py) still holds, but at 10 pages the lookup undercuts the 3x intent for
# that one save: a 10-page lookup needs 1,800+ rows containing the invoice text, so it is
# accepted. STALE_SAVING_SECONDS is unchanged.
# After the document is made and before the draft is marked saved, a save that created parts reads
# each back (vrcfw item 6, server._new_part_price_note): at most MAX_NEW_RECORDS single-attempt GETs
# (retry=False), stopped at the first error other than not-found and once
# server.NEW_PART_READBACK_SECONDS (20 s) is spent. It adds at most 20 s plus one GET already in
# flight (one attempt at the 55 s timeout, per httpx phase), about 75 s: small against the 2,670 s
# largest save above, and STALE_SAVING_SECONDS is unchanged.
MAX_NEW_RECORDS = 5
STALE_SAVING_SECONDS = 7200
MAX_DRAFT_ID = 2 ** 63 - 1

STATUSES = ("draft", "saving", "saved", "discarded", "failed", "reading")
OPEN_STATUSES = ("draft", "failed")
_UNSET = object()      # "no expect_key given" (None is a real value: no key stored)
LIST_STATUSES = ("draft", "failed", "reading")
TYPES = ("po", "bill", "so", "doc", "import")   # "doc": a background upload not read yet (or unreadable);
                                                # "import": a part import (86e3q4zek)
REVIEW_STATES = ("needs_review", "reviewed")
INTERRUPTED_DETAIL = "Reading was interrupted. Drop the file again."
DOCUMENT_RETENTION_DAYS = 30
IDEMPOTENCY_KEY_MAX = 64
AUDIT_ACTIONS = ("created", "updated", "discarded", "restored", "save_failed", "saved",
                 "undo_failed", "undone", "attached", "attach_failed", "retyped", "read_failed",
                 "record_created", "record_deleted", "record_delete_failed", "record_kept",
                 "part_updated", "part_restored",   # part import (86e3q4zek)
                 "part_update_sent", "part_create_sent",   # written before the import's PATCH / POST (vpa63)
                 "part_settled",     # closes a part's journal row once its outcome is known (vpa63)
                 "part_undo_sent",   # written before an Undo's restore PATCH / DELETE (vpa63)
                 "setting_changed")
IMPORT_JOURNAL_ACTIONS = ("part_update_sent", "part_create_sent")
IMPORT_SETTLED_ACTION = "part_settled"
IMPORT_UNDO_OUTCOMES = ("put_back", "dropped", "removed", "kept", "foreign")   # part_settled by Undo
IMPORT_UNDO_SENT_ACTION = "part_undo_sent"
# vpa63: an import's journal cycle starts after the draft's newest 'undone' row (a full Undo) or its
# 'created' row. drafts.id is INTEGER PRIMARY KEY without AUTOINCREMENT, so once the newest draft
# is purged (audit rows outlive it) a new draft can reuse its id: its own 'created' row (written in
# the same transaction as the insert, create_draft) hides the dead draft's journal rows.
IMPORT_CYCLE_START = "('undone', 'created')"

_DB_PATHS = [
    Path(r"C:\ProgramData\IntraMind\drafts.sqlite3"),
    Path(__file__).parent / "drafts.sqlite3",
]

_init_lock = threading.Lock()
log = logging.getLogger("ebms_live")
PURGE_CAP_FRACTION = 0.5          # one run may delete at most this share of a table's rows ...
PURGE_CAP_MIN_ROWS = 20           # ... unless the table has fewer rows than this
PURGE_CLOCK_FUTURE_DAYS = 1       # a stored timestamp later than now + this means the clock is wrong
PURGE_GAP_DAYS = 30               # first run: data whose newest row is older than this is "quiet"
PURGE_JUMP_DAYS = 2               # a gap longer than this since the last purge is judged against everything due
COPY_BACKOFF_SECONDS = 600        # at most one pre-migration copy attempt per path in this window
_copy_attempts: dict = {}
_audit_checked: set = set()       # resolved paths already healed or seen with audit.api_user (this process)
_audit_heal_failed: dict = {}     # resolved path -> monotonic time of a failed heal (retried after the backoff)


class DraftNotFound(Exception):
    """No such draft for this user and dataset (or it isn't theirs)."""


class StatusConflict(Exception):
    """The draft is not in a status that allows this step. The message is safe to show."""

    def __init__(self, message: str, draft: dict | None = None):
        super().__init__(message)
        self.draft = draft


class IdempotencyConflict(Exception):
    """The idempotency key was already used for a different draft or user."""


# ---------------------------------------------------------------------------
# Paths, connections, schema
# ---------------------------------------------------------------------------

def db_path(override: str | os.PathLike | None = None) -> Path:
    """Explicit argument > EBMS_LIVE_DRAFTS_DB > ProgramData (if the dir exists) > next to this file."""
    if override:
        return Path(override)
    env = os.getenv("EBMS_LIVE_DRAFTS_DB")
    if env:
        return Path(env)
    # os.name guard: on Linux/macOS a backslash path has no separators, so its parent is "."
    # (same trap pins_store.db_path documents).
    for p in _DB_PATHS if os.name == "nt" else _DB_PATHS[1:]:
        try:
            if p.parent.exists():
                return p
        except OSError:
            pass
    return _DB_PATHS[-1]


_PURGE_STATE_DDL = ("CREATE TABLE IF NOT EXISTS purge_state ("
                    "id INTEGER PRIMARY KEY CHECK (id = 1), last_purge_at TEXT NOT NULL)")


def _ensure_schema(conn: sqlite3.Connection, verify=None) -> None:
    version = conn.execute("PRAGMA user_version").fetchone()[0]
    if version >= SCHEMA_VERSION:
        return
    conn.execute("BEGIN IMMEDIATE")
    try:
        conn.execute(
            """CREATE TABLE IF NOT EXISTS drafts (
                   id INTEGER PRIMARY KEY,
                   username TEXT NOT NULL,
                   schema TEXT NOT NULL,
                   type TEXT NOT NULL,
                   status TEXT NOT NULL,
                   payload TEXT NOT NULL,
                   card TEXT,
                   idempotency_key TEXT UNIQUE,
                   cycle INTEGER NOT NULL DEFAULT 0,
                   ebms_doc_number TEXT,
                   ebms_doc_id TEXT,
                   saved_by TEXT,
                   saved_at TEXT,
                   created_at TEXT NOT NULL,
                   updated_at TEXT NOT NULL
               )"""
        )
        conn.execute("CREATE INDEX IF NOT EXISTS drafts_owner ON drafts (username, schema, status)")
        conn.execute(
            """CREATE TABLE IF NOT EXISTS idem_keys (
                   key TEXT PRIMARY KEY,
                   draft_id INTEGER NOT NULL,
                   cycle INTEGER NOT NULL,
                   username TEXT NOT NULL,
                   schema TEXT NOT NULL,
                   created_at TEXT NOT NULL
               )"""
        )
        conn.execute(
            """CREATE TABLE IF NOT EXISTS audit (
                   id INTEGER PRIMARY KEY,
                   at TEXT NOT NULL,
                   username TEXT NOT NULL,
                   schema TEXT NOT NULL,
                   draft_id INTEGER,
                   action TEXT NOT NULL,
                   type TEXT,
                   doc_number TEXT,
                   before TEXT,
                   after TEXT,
                   request_id TEXT,
                   response_id TEXT,
                   api_user TEXT,
                   detail TEXT
               )"""
        )
        conn.execute("CREATE INDEX IF NOT EXISTS audit_schema ON audit (schema, id)")
        # v6 (vpa6m): a file whose audit table predates api_user (the first drafts_store.py, commit
        # 6273bc4) gets the column here, inside the same transaction, pre-v6 copy and verify. A file
        # already at v6 without it is healed by _heal_audit_api_user (called from _connect).
        acols = {r[1] for r in conn.execute("PRAGMA table_info(audit)").fetchall()}
        if "api_user" not in acols:
            conn.execute("ALTER TABLE audit ADD COLUMN api_user TEXT")
        # v2 (86e3q4zeb): an uploaded bill's original bytes, one per draft. Every statement
        # above is IF NOT EXISTS, so a v1 file upgrades by running this whole block again.
        conn.execute(
            """CREATE TABLE IF NOT EXISTS documents (
                   draft_id INTEGER PRIMARY KEY,
                   username TEXT NOT NULL,
                   schema TEXT NOT NULL,
                   filename TEXT NOT NULL,
                   content_type TEXT NOT NULL,
                   size INTEGER NOT NULL,
                   sha256 TEXT NOT NULL,
                   pages INTEGER,
                   data BLOB NOT NULL,
                   created_at TEXT NOT NULL
               )"""
        )
        conn.execute("CREATE INDEX IF NOT EXISTS documents_created ON documents (created_at)")
        # v3 (86e3q4ze8): review list. ADD COLUMN has no IF NOT EXISTS, so check first.
        cols = {r[1] for r in conn.execute("PRAGMA table_info(drafts)").fetchall()}
        if "review_state" not in cols:
            conn.execute("ALTER TABLE drafts ADD COLUMN review_state TEXT NOT NULL DEFAULT 'reviewed'")
        if "detail" not in cols:
            conn.execute("ALTER TABLE drafts ADD COLUMN detail TEXT")
        # v4: per-user data-entry settings (Settings > Data entry)
        conn.execute(
            """CREATE TABLE IF NOT EXISTS user_settings (
                   username TEXT NOT NULL,
                   schema TEXT NOT NULL,
                   key TEXT NOT NULL,
                   value TEXT NOT NULL,
                   updated_at TEXT NOT NULL,
                   PRIMARY KEY (username, schema, key)
               )"""
        )
        # v5: company-wide settings per dataset (Settings > Company, EBMS Administrators)
        conn.execute(
            """CREATE TABLE IF NOT EXISTS company_settings (
                   schema TEXT NOT NULL,
                   key TEXT NOT NULL,
                   value TEXT NOT NULL,
                   updated_at TEXT NOT NULL,
                   updated_by TEXT NOT NULL,
                   PRIMARY KEY (schema, key)
               )"""
        )
        # Append-only, enforced by the database too (spec 11.9).
        conn.execute(
            "CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit "
            "BEGIN SELECT RAISE(ABORT, 'audit is append-only'); END"
        )
        # v6: rows older than a year may be deleted (purge_audit); younger rows may not.
        conn.execute("DROP TRIGGER IF EXISTS audit_no_delete")
        conn.execute(
            "CREATE TRIGGER audit_no_delete BEFORE DELETE ON audit "
            f"WHEN OLD.at >= strftime('%Y-%m-%dT%H:%M:%f', 'now', '-{AUDIT_RETENTION_DAYS} days') "
            "BEGIN SELECT RAISE(ABORT, 'audit rows are kept for one year'); END"
        )
        # v6: when the last clean retention run finished (single row, id 1); see purge_all
        conn.execute(_PURGE_STATE_DDL)
        conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
        if verify is not None:
            verify(conn)            # inside the transaction: a failed check rolls the upgrade back
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        raise


def _is_nonempty(conn) -> bool:
    return conn.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' "
                        "AND name NOT LIKE 'sqlite_%' LIMIT 1").fetchone() is not None


def _count3(conn) -> tuple:
    """drafts/documents/audit row counts. A table the file does not have yet (a v1 file has no
    documents table) counts as 0, so the same call works on the copy and after the upgrade."""
    have = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    return tuple(conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] if t in have else 0
                 for t in ("drafts", "documents", "audit"))


class _MigrationCheckFailed(sqlite3.DatabaseError):
    pass


def _integrity_ok(conn) -> bool:
    return conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


def _wipe_files(base: Path) -> None:
    """Remove a copy of the data and its -wal/-shm. The bytes are zeroed first: the copy holds the
    same drafts and bills as the original, so an unlinked file must not leave them on the disk."""
    for suffix in ("", "-wal", "-shm", "-journal"):
        f = base.with_name(base.name + suffix)
        try:
            if f.exists():
                size = f.stat().st_size
                with open(f, "r+b") as fh:
                    fh.write(b"\0" * size)
                    fh.flush()
                    os.fsync(fh.fileno())
                f.unlink()
        except OSError:
            log.warning("Assist drafts file: a leftover copy could not be removed")


def _backup_before_migration(conn: sqlite3.Connection, p: Path) -> Path | None:
    """Consistent copy of the file next to it (drafts.sqlite3.pre-v6) via the backup API. Written
    under a temp name and renamed, so a half-written copy never stands in for a good one. Any
    failure returns None (the migration is one atomic transaction: a missing safety copy must not
    block Assist) after removing the partial file."""
    final = p.with_name(p.name + ".pre-v6")
    tmp = p.with_name(p.name + ".pre-v6.tmp")
    try:
        _wipe_files(tmp)
        dest = sqlite3.connect(str(tmp))
        try:
            dest.execute("PRAGMA secure_delete = ON")
            conn.backup(dest)
            dest.execute("PRAGMA journal_mode = DELETE")
        finally:
            dest.close()
        for suffix in ("-wal", "-shm"):
            _wipe_files(final.with_name(final.name + suffix))
        _wipe_files(final)                    # an older copy: zeroed before it is replaced
        os.replace(tmp, final)
        return final
    except Exception:
        _wipe_files(tmp)
        log.warning("Assist drafts file: the safety copy before the upgrade could not be made; "
                    "upgrading without it")
        return None


def _migrate_with_copy(conn: sqlite3.Connection, p: Path) -> None:
    """Upgrade the file to SCHEMA_VERSION. A non-empty older file is copied first (pre-v6 copy, at
    most once per COPY_BACKOFF_SECONDS per path). integrity_check and the drafts/documents/audit
    counts are verified inside the migration transaction: a failed check rolls the upgrade back, the
    copy (which only duplicates the intact original) is deleted and the error is raised. A failure of
    the migration itself leaves the copy in place."""
    version = conn.execute("PRAGMA user_version").fetchone()[0]
    if version >= SCHEMA_VERSION:
        return                                   # another thread migrated while we waited for the lock
    copy = None
    counts = None
    if _is_nonempty(conn):
        key = str(p.resolve())
        now = time.monotonic()
        if now - _copy_attempts.get(key, -COPY_BACKOFF_SECONDS * 2) >= COPY_BACKOFF_SECONDS:
            _copy_attempts[key] = now
            copy = _backup_before_migration(conn, p)
            if copy is not None:
                c = sqlite3.connect(str(copy))
                try:
                    counts = _count3(c)
                finally:
                    c.close()
    conn.execute("PRAGMA journal_mode = WAL")

    def verify(c):
        if not _integrity_ok(c):
            raise _MigrationCheckFailed("integrity check failed after migration")
        if counts is not None and _count3(c) != counts:
            raise _MigrationCheckFailed("row counts changed during migration")
    try:
        _ensure_schema(conn, verify=verify)
    except _MigrationCheckFailed:
        if copy is not None:
            _wipe_files(copy)
        log.error("Assist drafts file migration check failed; the upgrade was rolled back")
        raise
    except BaseException:
        if copy is not None:
            log.error("Assist drafts file migration failed; the copy before the upgrade was kept "
                      "(drafts.sqlite3.pre-v6)")
        raise
    if copy is not None:
        _wipe_files(copy)


def _heal_audit_api_user(conn: sqlite3.Connection, p: Path) -> None:
    """A file already at SCHEMA_VERSION whose audit table has no api_user column (made by this code
    between the first data-entry build and commit b8ec468) gets it here: one nullable column in one
    transaction, integrity_check and drafts/documents/audit counts verified before COMMIT, else
    ROLLBACK. Checked once per path per process; the check is read-only, and a file that has the
    column is never written. Never raises: on any failure it logs and carries on (the audited writes
    then fail as they did before, and the next attempt is after COPY_BACKOFF_SECONDS)."""
    raw = str(p)
    if raw in _audit_checked:                    # cheap hit: no syscall, no query
        return
    key = raw

    def missing(c) -> bool:
        cols = [r[1] for r in c.execute("PRAGMA table_info(audit)").fetchall()]
        return bool(cols) and "api_user" not in cols
    try:
        key = str(p.resolve())
        if key in _audit_checked:
            with _init_lock:
                _audit_checked.add(raw)
            return
        # only a file at exactly SCHEMA_VERSION: older code must never alter a newer schema
        if conn.execute("PRAGMA user_version").fetchone()[0] != SCHEMA_VERSION:
            return
        if not missing(conn):
            with _init_lock:
                _audit_checked.update((raw, key))
            return
        with _init_lock:
            if key in _audit_checked:
                return
            last = _audit_heal_failed.get(key)
            if last is not None and time.monotonic() - last < COPY_BACKOFF_SECONDS:
                return
            conn.execute("BEGIN IMMEDIATE")
            try:
                if missing(conn):                # re-check: another process may have healed it
                    before = _count3(conn)
                    conn.execute("ALTER TABLE audit ADD COLUMN api_user TEXT")
                    if not _integrity_ok(conn):
                        raise _MigrationCheckFailed("integrity check failed")
                    if _count3(conn) != before:
                        raise _MigrationCheckFailed("row count check failed")
                conn.execute("COMMIT")
            except BaseException:
                try:
                    conn.execute("ROLLBACK")
                except sqlite3.Error:
                    pass
                raise
            _audit_heal_failed.pop(key, None)
            _audit_checked.update((raw, key))
    except Exception as e:
        with _init_lock:
            _audit_heal_failed[key] = time.monotonic()
        log.error("drafts file could not add audit.api_user (%s)", type(e).__name__)


def _connect(path: str | os.PathLike | None = None) -> sqlite3.Connection:
    p = db_path(path)
    conn = sqlite3.connect(str(p), timeout=BUSY_TIMEOUT_SECONDS, isolation_level=None)
    try:
        conn.row_factory = sqlite3.Row
        conn.execute(f"PRAGMA busy_timeout = {int(BUSY_TIMEOUT_SECONDS * 1000)}")
        conn.execute("PRAGMA secure_delete = ON")   # freed pages are zeroed (retention purges)
        if conn.execute("PRAGMA user_version").fetchone()[0] < SCHEMA_VERSION:
            with _init_lock:
                _migrate_with_copy(conn, p)
        _heal_audit_api_user(conn, p)
    except BaseException:
        conn.close()
        raise
    return conn


def _norm_user(username: str) -> str:
    return (username or "").strip().upper()


def _norm_schema(schema: str) -> str:
    return (schema or "").strip()


def _owner(username: str, schema: str) -> tuple[str, str]:
    u, s = _norm_user(username), _norm_schema(schema)
    if not u or not s:
        raise ValueError("A draft needs a signed-in user and a dataset.")
    return u, s


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def purge_audit(*, days: int = AUDIT_RETENTION_DAYS, path=None) -> int:
    """Delete audit rows older than `days` (never fewer than AUDIT_RETENTION_DAYS). Returns the count."""
    keep = max(int(days), AUDIT_RETENTION_DAYS)
    cutoff = (datetime.now(timezone.utc) - timedelta(days=keep)).isoformat(timespec="microseconds")
    with _Tx(path) as conn:
        return conn.execute("DELETE FROM audit WHERE at < ?", (cutoff,)).rowcount


def _dumps(value) -> str | None:
    if value is None:
        return None
    return json.dumps(value, default=str, sort_keys=True)


def _row(row: sqlite3.Row | None) -> dict | None:
    if row is None:
        return None
    d = dict(row)
    d["payload"] = json.loads(d["payload"]) if d.get("payload") else {}
    d["card"] = json.loads(d["card"]) if d.get("card") else None
    return d


def _pid(draft_id) -> int:
    try:
        pid = int(draft_id)
    except (TypeError, ValueError, OverflowError):
        raise DraftNotFound()
    if not 1 <= pid <= MAX_DRAFT_ID:  # SQLite INTEGER range (review #8: OverflowError -> 503)
        raise DraftNotFound()
    return pid


def _load(conn, u: str, s: str, draft_id: int) -> dict:
    row = conn.execute(
        "SELECT * FROM drafts WHERE id = ? AND username = ? AND schema = ?", (draft_id, u, s)
    ).fetchone()
    if row is None:
        raise DraftNotFound()
    return _row(row)


def _audit(conn, *, username: str, schema: str, draft_id, action: str, type_: str | None,
           doc_number=None, before=None, after=None, request_id=None, response_id=None,
           detail=None, api_user=None) -> int:
    """api_user: the EBMS username the API call ran as (each call runs as the signed-in user,
    owner decision 2026-10-14). NEVER a password: only the name is passed in."""
    if action not in AUDIT_ACTIONS:
        raise ValueError(f"unknown audit action {action!r}")
    cur = conn.execute(
        "INSERT INTO audit (at, username, schema, draft_id, action, type, doc_number, before,"
        " after, request_id, response_id, api_user, detail) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (_now(), username, schema, draft_id, action, type_,
         None if doc_number is None else str(doc_number), _dumps(before), _dumps(after),
         None if request_id is None else str(request_id)[:200],
         None if response_id is None else str(response_id)[:200],
         None if api_user is None else str(api_user)[:100],
         None if detail is None else str(detail)[:2000]),
    )
    return cur.lastrowid


class _Tx:
    """BEGIN IMMEDIATE ... COMMIT/ROLLBACK on a fresh connection."""

    def __init__(self, path):
        self.path = path

    def __enter__(self):
        self.conn = _connect(self.path)
        self.conn.execute("BEGIN IMMEDIATE")
        return self.conn

    def __exit__(self, exc_type, exc, tb):
        try:
            self.conn.execute("ROLLBACK" if exc_type else "COMMIT")
        finally:
            self.conn.close()
        return False


# ---------------------------------------------------------------------------
# Drafts
# ---------------------------------------------------------------------------

def _store_document(conn, draft_id: int, u: str, s: str, document: dict, now: str) -> None:
    data = document["data"]
    if not isinstance(data, (bytes, bytearray)) or not data:
        raise ValueError("The document is empty.")
    conn.execute(
        "INSERT INTO documents (draft_id, username, schema, filename, content_type, size, sha256,"
        " pages, data, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (draft_id, u, s, str(document.get("filename") or "document")[:200],
         str(document["content_type"]), len(data), str(document.get("sha256") or ""),
         document.get("pages"), sqlite3.Binary(bytes(data)), now),
    )


def create_draft(username: str, schema: str, type_: str, payload: dict, card: dict | None = None,
                 *, audit_after=None, document: dict | None = None, review_state: str = "reviewed",
                 path=None) -> dict:
    """Insert a new draft (status draft) and its 'created' audit row in one transaction.
    document (bills, orders): {filename, content_type, data (bytes), sha256, pages} stored with it.
    review_state: 'needs_review' for drafts made from a document or plain text."""
    u, s = _owner(username, schema)
    if type_ not in TYPES or type_ == "doc":
        raise ValueError("Unsupported document type.")
    if review_state not in REVIEW_STATES:
        raise ValueError("Unknown review state.")
    now = _now()
    with _Tx(path) as conn:
        cur = conn.execute(
            "INSERT INTO drafts (username, schema, type, status, payload, card, review_state, created_at, updated_at)"
            " VALUES (?, ?, ?, 'draft', ?, ?, ?, ?, ?)",
            (u, s, type_, _dumps(payload or {}), _dumps(card), review_state, now, now),
        )
        draft_id = cur.lastrowid
        if document is not None:
            _store_document(conn, draft_id, u, s, document, now)
        _audit(conn, username=u, schema=s, draft_id=draft_id, action="created", type_=type_,
               after=audit_after)
        return _load(conn, u, s, draft_id)


def create_placeholder(username: str, schema: str, *, payload: dict, card: dict | None,
                       document: dict, path=None) -> dict:
    """A background upload not read yet: type 'doc', status 'reading', needs_review, with its
    file stored. No audit row until it is read (fill_draft) or fails (fail_reading)."""
    u, s = _owner(username, schema)
    now = _now()
    with _Tx(path) as conn:
        cur = conn.execute(
            "INSERT INTO drafts (username, schema, type, status, payload, card, review_state, created_at, updated_at)"
            " VALUES (?, ?, 'doc', 'reading', ?, ?, 'needs_review', ?, ?)",
            (u, s, _dumps(payload or {}), _dumps(card), now, now),
        )
        _store_document(conn, cur.lastrowid, u, s, document, now)
        return _load(conn, u, s, cur.lastrowid)


def fill_draft(username: str, schema: str, draft_id, type_: str, payload: dict, card: dict | None, *,
               audit_after=None, path=None) -> dict:
    """reading -> draft once the document has been read, with the 'created' audit row."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    if type_ not in TYPES or type_ == "doc":
        raise ValueError("Unsupported document type.")
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "reading":
            raise StatusConflict("This document is no longer being read.", d)
        conn.execute("UPDATE drafts SET type = ?, status = 'draft', payload = ?, card = ?, detail = NULL,"
                     " updated_at = ? WHERE id = ?", (type_, _dumps(payload or {}), _dumps(card), _now(), pid))
        _audit(conn, username=u, schema=s, draft_id=pid, action="created", type_=type_, after=audit_after)
        return _load(conn, u, s, pid)


def fail_reading(username: str, schema: str, draft_id, detail: str, *, path=None) -> dict:
    """reading -> failed with a human `detail` (shown in the Review list)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "reading":
            return d
        conn.execute("UPDATE drafts SET status = 'failed', detail = ?, updated_at = ? WHERE id = ?",
                     (str(detail)[:500], _now(), pid))
        _audit(conn, username=u, schema=s, draft_id=pid, action="read_failed", type_=d["type"],
               detail=str(detail)[:500])
        return _load(conn, u, s, pid)


def fail_interrupted(*, path=None) -> int:
    """Startup: reading jobs are in memory, so any draft still 'reading' was interrupted."""
    with _Tx(path) as conn:
        rows = conn.execute("SELECT id, username, schema, type FROM drafts WHERE status = 'reading'").fetchall()
        for r in rows:
            conn.execute("UPDATE drafts SET status = 'failed', detail = ?, updated_at = ? WHERE id = ?",
                         (INTERRUPTED_DETAIL, _now(), r["id"]))
            _audit(conn, username=r["username"], schema=r["schema"], draft_id=r["id"], action="read_failed",
                   type_=r["type"], detail=INTERRUPTED_DETAIL)
        return len(rows)


IMPORT_INTERRUPTED_DETAIL = ("IntraMind restarted while this import was running. The parts already done are "
                             "kept; press Save to do the rest.")


def fail_interrupted_imports(*, path=None) -> int:
    """Startup: an import save runs in a background thread, so an import still 'saving' was
    interrupted. Its progress is in the payload (import_results); a new Save does the rest."""
    with _Tx(path) as conn:
        rows = conn.execute("SELECT id, username, schema, type FROM drafts WHERE status = 'saving' AND type = 'import'"
                            ).fetchall()
        for r in rows:
            conn.execute("UPDATE drafts SET status = 'failed', detail = ?, updated_at = ? WHERE id = ?",
                         (IMPORT_INTERRUPTED_DETAIL, _now(), r["id"]))
            _audit(conn, username=r["username"], schema=r["schema"], draft_id=r["id"], action="save_failed",
                   type_=r["type"], detail=IMPORT_INTERRUPTED_DETAIL)
        return len(rows)


SAVE_INTERRUPTED_DETAIL = ("IntraMind restarted while this was being saved. Check EBMS or Activity to see "
                           "whether it went through. If not, press Save to try again.")


def fail_interrupted_saves(*, path=None) -> int:
    """Startup: a PO, sales order or bill save runs inside a request, so any such draft still
    'saving' when the service starts was cut off. It becomes 'failed' (visible in Review) and keeps
    its idempotency key, so Save again goes through claim_save, reuses that key and EBMS finds
    the document if the cut-off call did create it. Imports are handled by
    fail_interrupted_imports. Returns how many were changed."""
    with _Tx(path) as conn:
        rows = conn.execute("SELECT id, username, schema, type FROM drafts WHERE status = 'saving' AND type != 'import'"
                            ).fetchall()
        for r in rows:
            conn.execute("UPDATE drafts SET status = 'failed', detail = ?, updated_at = ? WHERE id = ?",
                         (SAVE_INTERRUPTED_DETAIL, _now(), r["id"]))
            _audit(conn, username=r["username"], schema=r["schema"], draft_id=r["id"], action="save_failed",
                   type_=r["type"], detail=SAVE_INTERRUPTED_DETAIL)
        return len(rows)


def set_review_state(username: str, schema: str, draft_id, state: str, *, path=None) -> dict:
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    if state not in REVIEW_STATES:
        raise ValueError("Unknown review state.")
    with _Tx(path) as conn:
        _load(conn, u, s, pid)
        conn.execute("UPDATE drafts SET review_state = ? WHERE id = ?", (state, pid))
        return _load(conn, u, s, pid)


def retype_draft(username: str, schema: str, draft_id, type_: str, payload: dict, card: dict | None, *,
                 before=None, after=None, expect_key=_UNSET, expect_updated_at=_UNSET, path=None) -> dict:
    """An unsaved draft from a document, re-read as the other type (same id and document).
    expect_key: the EBMS key the caller checked against EBMS; it must still be the stored one
    (this nulls it), else StatusConflict."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    if type_ not in TYPES or type_ == "doc":
        raise ValueError("Unsupported document type.")
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] not in OPEN_STATUSES:
            raise StatusConflict(_status_message(d["status"], "changed"), d)
        if ((expect_key is not _UNSET and d["idempotency_key"] != expect_key)
                or (expect_updated_at is not _UNSET and d["updated_at"] != expect_updated_at)):
            raise StatusConflict(_status_message("draft", "changed"), d)
        conn.execute("UPDATE drafts SET type = ?, status = 'draft', payload = ?, card = ?, detail = NULL,"
                     " idempotency_key = NULL, cycle = cycle + 1, updated_at = ? WHERE id = ?",
                     (type_, _dumps(payload or {}), _dumps(card), _now(), pid))
        _audit(conn, username=u, schema=s, draft_id=pid, action="retyped", type_=type_,
               before=before, after=after)
        return _load(conn, u, s, pid)


def get_draft(username: str, schema: str, draft_id, *, path=None) -> dict:
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    conn = _connect(path)
    try:
        return _load(conn, u, s, pid)
    finally:
        conn.close()


def list_drafts(username: str, schema: str, statuses=LIST_STATUSES, *, path=None) -> list[dict]:
    """This user's drafts for this dataset in the given statuses: needs_review and reading
    first, then newest first."""
    u, s = _owner(username, schema)
    statuses = tuple(statuses)
    marks = ",".join("?" for _ in statuses)
    conn = _connect(path)
    try:
        rows = conn.execute(
            f"SELECT * FROM drafts WHERE username = ? AND schema = ? AND status IN ({marks})"
            " ORDER BY CASE WHEN status = 'reading' OR review_state = 'needs_review' THEN 0 ELSE 1 END,"
            " updated_at DESC, id DESC",
            (u, s, *statuses),
        ).fetchall()
    finally:
        conn.close()
    return [_row(r) for r in rows]


def update_draft(username: str, schema: str, draft_id, payload: dict, card: dict | None, *,
                 audit_before=None, audit_after=None, rotate_key: bool = False, expect_key=_UNSET,
                 expect_updated_at=_UNSET, path=None) -> dict:
    """Replace payload + card. Only from draft|failed; a failed draft goes back to draft.
    rotate_key=True clears the cycle's EBMS key and starts a new cycle: the caller checked
    EBMS has no document for the old key, so the edited lines can never be answered by a
    document an earlier attempt made with the old lines (review #6). expect_key: the key the
    caller looked up in EBMS; if another request changed it meanwhile the edit is refused
    (StatusConflict), so a key that may now name a document is never cleared by mistake.
    expect_updated_at does the same for the whole draft: a save that failed with the same key
    between the lookup and this update changed nothing about the key but touched the draft."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] not in OPEN_STATUSES:
            raise StatusConflict(_status_message(d["status"], "edited"), d)
        if ((expect_key is not _UNSET and d["idempotency_key"] != expect_key)
                or (expect_updated_at is not _UNSET and d["updated_at"] != expect_updated_at)):
            raise StatusConflict(_status_message("draft", "edited"), d)
        if rotate_key:
            conn.execute("UPDATE drafts SET idempotency_key = NULL, cycle = cycle + 1 WHERE id = ?", (pid,))
        conn.execute(
            "UPDATE drafts SET payload = ?, card = ?, status = 'draft', review_state = 'reviewed', detail = NULL,"
            " updated_at = ? WHERE id = ?",
            (_dumps(payload or {}), _dumps(card), _now(), pid),
        )
        _audit(conn, username=u, schema=s, draft_id=pid, action="updated", type_=d["type"],
               before=audit_before, after=audit_after)
        return _load(conn, u, s, pid)


def set_card(username: str, schema: str, draft_id, card: dict, *, only_if_status: tuple[str, ...] | None = None,
             path=None) -> dict:
    """Store the last rendered card without changing status (no audit: nothing changed).

    only_if_status: when given and the draft's status (read in this same transaction) is not in
    it, nothing is written and the draft is returned as it is. get_draft passes OPEN_STATUSES so
    a card rendered before a save finished never overwrites the saved card (vpa6b). The default
    keeps writing on any status (_attach_bill_document updates a saved draft's card)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if only_if_status is not None and d["status"] not in only_if_status:
            return d
        conn.execute("UPDATE drafts SET card = ? WHERE id = ?", (_dumps(card), pid))
        return _load(conn, u, s, pid)


def set_payload(username: str, schema: str, draft_id, payload: dict, *, path=None) -> dict:
    """Replace the payload of a draft that is being saved (status 'saving'), without changing
    status. Match to PO stores the PO's "before" snapshot here BEFORE it PATCHes EBMS, so undo
    and a retry after a timeout can always find it."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "saving":
            raise StatusConflict("This draft is no longer being saved.", d)
        conn.execute("UPDATE drafts SET payload = ?, updated_at = ? WHERE id = ?", (_dumps(payload or {}), _now(), pid))
        return _load(conn, u, s, pid)


def set_saved_card(username: str, schema: str, draft_id, card: dict, payload: dict, *,
                   statuses: tuple[str, ...] = ("saved",), detail=_UNSET, path=None) -> dict:
    """A saved draft keeps status 'saved' with a new card and payload: a part import that was
    only partly undone (the payload says what is still in EBMS; Undo again tries the rest).
    statuses: the statuses this may be called on (the status itself never changes). A part
    import's Undo also passes 'failed' and 'draft' (an unfinished import, vpa63); every other
    caller keeps the default. detail, when given, replaces the draft's detail (the Review list
    text of a failed import that was partly undone)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] not in statuses:
            raise StatusConflict("This draft is no longer saved.", d)
        conn.execute("UPDATE drafts SET card = ?, payload = ?, updated_at = ? WHERE id = ?",
                     (_dumps(card), _dumps(payload or {}), _now(), pid))
        if detail is not _UNSET:
            conn.execute("UPDATE drafts SET detail = ? WHERE id = ?", (detail, pid))
        return _load(conn, u, s, pid)


def discard_draft(username: str, schema: str, draft_id, *, summary=None, path=None) -> dict:
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] == "discarded":
            return d
        if d["status"] not in OPEN_STATUSES:
            raise StatusConflict(_status_message(d["status"], "discarded"), d)
        conn.execute("UPDATE drafts SET status = 'discarded', updated_at = ? WHERE id = ?", (_now(), pid))
        _audit(conn, username=u, schema=s, draft_id=pid, action="discarded", type_=d["type"],
               before={"status": d["status"], **(summary or {})},
               after={"status": "discarded", **(summary or {})})
        return _load(conn, u, s, pid)


def restore_draft(username: str, schema: str, draft_id, *, summary=None, path=None) -> dict:
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] in OPEN_STATUSES:
            return d
        if d["status"] != "discarded":
            raise StatusConflict(_status_message(d["status"], "restored"), d)
        conn.execute("UPDATE drafts SET status = 'draft', updated_at = ? WHERE id = ?", (_now(), pid))
        _audit(conn, username=u, schema=s, draft_id=pid, action="restored", type_=d["type"],
               before={"status": "discarded", **(summary or {})},
               after={"status": "draft", **(summary or {})})
        return _load(conn, u, s, pid)


def _key(value) -> str:
    return str(value or "").strip().upper()


def recent_reorder_items(schema: str, vendor_id: str, *, minutes: int = 60, path=None) -> list[str]:
    """Part IDs (upper-cased, trimmed) on reorder purchase-order drafts of ANY user in this
    dataset, for this vendor, that are saved, or saving and not stale, and were saved or last
    touched within the last `minutes`. The mirror lags EBMS, so right after such a PO is saved
    the mirror still shows its parts as low and not on an open PO; this is what stops a second
    reorder request from drafting the same parts again. It sees this app's own drafts only, never
    a PO entered directly in EBMS. Payload keys (drafts_po.py): "source" == "reorder",
    "reorder_vendor" the vendor ID, "lines"[i]["item"] the part IDs."""
    s = _norm_schema(schema)
    v = _key(vendor_id)
    if not s or not v:
        return []
    conn = _connect(path)
    try:
        rows = conn.execute(
            "SELECT status, payload, saved_at, updated_at FROM drafts WHERE schema = ? AND type = 'po'"
            " AND status IN ('saved', 'saving') ORDER BY id", (s,)).fetchall()
    finally:
        conn.close()
    cutoff = datetime.now(timezone.utc) - timedelta(minutes=minutes)
    out: list[str] = []
    seen = set()
    for r in rows:
        stamp = (r["saved_at"] if r["status"] == "saved" else None) or r["updated_at"]
        try:
            when = datetime.fromisoformat(stamp)
        except (TypeError, ValueError):
            continue
        if when < cutoff or (r["status"] == "saving" and _stale(r["updated_at"])):
            continue
        try:
            p = json.loads(r["payload"]) if r["payload"] else {}
        except ValueError:
            continue
        if not isinstance(p, dict) or p.get("source") != "reorder" or _key(p.get("reorder_vendor")) != v:
            continue
        for ln in p.get("lines") or []:
            item = _key(ln.get("item")) if isinstance(ln, dict) else ""
            if item and item not in seen:
                seen.add(item)
                out.append(item)
    return out


def find_bill_conflict(schema: str, vendor_id: str, invoice: str, exclude_id, *, path=None) -> dict | None:
    """The first bill draft of ANY user in this dataset that is saved or saving for the same
    vendor and invoice number (trimmed, upper-cased), other than exclude_id. Any other saving
    draft counts, whatever its id: two saves that start at the same instant both refuse (no bill
    is made and each can be retried), which is safer than letting the older one through while the
    newer one is already creating. A saving draft that is stale (STALE_SAVING_SECONDS, the same
    rule claim_save uses) is ignored: its save died with a restart or crash. A saved draft never
    goes stale. Returns {id, status, doc_number} or None. Payload keys (drafts_bill.py): "vendor" is the
    resolved vendor ID, "new_vendor"["id"] a vendor being created (used only while "vendor" is
    empty), "invoice_number" the invoice number. An empty vendor or invoice never matches."""
    s = _norm_schema(schema)
    v, inv = _key(vendor_id), _key(invoice)
    if not s or not v or not inv:
        return None
    try:
        ex = int(exclude_id) if exclude_id is not None else None
    except (TypeError, ValueError):
        ex = None
    conn = _connect(path)
    try:
        rows = conn.execute(
            "SELECT id, status, payload, ebms_doc_number, updated_at FROM drafts WHERE schema = ? AND type = 'bill'"
            " AND status IN ('saved', 'saving') ORDER BY id", (s,)).fetchall()
    finally:
        conn.close()
    for r in rows:
        if ex is not None and r["id"] == ex:
            continue
        if r["status"] == "saving" and _stale(r["updated_at"]):
            continue
        try:
            p = json.loads(r["payload"]) if r["payload"] else {}
        except ValueError:
            continue
        if not isinstance(p, dict):
            continue
        nv = p.get("new_vendor")
        pv = _key(p.get("vendor")) or _key(nv.get("id") if isinstance(nv, dict) else None)
        if pv == v and _key(p.get("invoice_number")) == inv:
            return {"id": r["id"], "status": r["status"], "doc_number": r["ebms_doc_number"]}
    return None


def find_open_by_sha(username: str, schema: str, sha256: str, exclude_id=None, *, path=None) -> dict | None:
    """This user's draft (same dataset) whose stored upload has this SHA-256 and whose status is
    draft, failed, reading or saving. Returns {id, status} or None."""
    u, s = _owner(username, schema)
    sha = str(sha256 or "").strip()
    if not sha:
        return None
    try:
        ex = int(exclude_id) if exclude_id is not None else None
    except (TypeError, ValueError):
        ex = None
    conn = _connect(path)
    try:
        row = conn.execute(
            "SELECT d.id AS id, d.status AS status FROM drafts d JOIN documents x ON x.draft_id = d.id"
            " WHERE d.username = ? AND d.schema = ? AND x.sha256 = ?"
            " AND d.status IN ('draft', 'failed', 'reading', 'saving') AND d.id != ?"
            " ORDER BY d.id LIMIT 1", (u, s, sha, -1 if ex is None else ex)).fetchone()
    finally:
        conn.close()
    return None if row is None else {"id": row["id"], "status": row["status"]}


_ACTIVITY_KEYS = ("vendor", "vendor_name", "customer", "customer_name", "po", "invoice", "parts", "total")


def _activity_summary_of(card_json) -> dict:
    """The vendor / invoice / total keys of a stored card's _summary, for audit rows (the same
    keys server._activity_brief puts on a single discard, so Activity reads the same)."""
    try:
        card = json.loads(card_json) if card_json else {}
        sm = card.get("_summary") if isinstance(card, dict) else None
    except ValueError:
        return {}
    if not isinstance(sm, dict):
        return {}
    return {k: sm.get(k) for k in _ACTIVITY_KEYS if k in sm}


def clear_drafts(username: str, schema: str, *, include_saved: bool = False, skip_ids=(), path=None) -> int:
    """Discard every draft of this user in this dataset that is in the Review list (draft,
    failed, reading), plus saved ones when include_saved, in ONE transaction: soft discard, one
    'discarded' audit row each, and the stored upload deleted. 'saving' drafts and other users'
    drafts are never touched. Not touching 'saving' is deliberate (a live save must not be killed);
    a saving row left by a restart is failed at startup (fail_interrupted_saves). include_saved is
    for a simulated-EBMS reset only: the discarded row keeps its EBMS fields. skip_ids are left as they
    are (vpa63: part imports whose Undo is running, which Discard refuses). Returns how many were cleared."""
    u, s = _owner(username, schema)
    statuses = LIST_STATUSES + (("saved",) if include_saved else ())
    marks = ",".join("?" for _ in statuses)
    with _Tx(path) as conn:
        rows = conn.execute(
            f"SELECT id, type, status, card FROM drafts WHERE username = ? AND schema = ? AND status IN ({marks})"
            " ORDER BY id", (u, s, *statuses)).fetchall()
        skip = {int(i) for i in skip_ids}
        rows = [r for r in rows if r["id"] not in skip]
        now = _now()
        for r in rows:
            conn.execute("UPDATE drafts SET status = 'discarded', updated_at = ? WHERE id = ?", (now, r["id"]))
            conn.execute("DELETE FROM documents WHERE draft_id = ? AND username = ? AND schema = ?",
                         (r["id"], u, s))
            _audit(conn, username=u, schema=s, draft_id=r["id"], action="discarded", type_=r["type"],
                   before={"status": r["status"], **_activity_summary_of(r["card"])},
                   after={"status": "discarded", **_activity_summary_of(r["card"])})
        return len(rows)


def _status_message(status: str, verb: str) -> str:
    return {
        "saving": "This draft is being saved right now.",
        "saved": f"This draft is already saved to EBMS, so it can't be {verb}. Undo it first.",
        "discarded": f"This draft was discarded. Restore it before it can be {verb}.",
    }.get(status, f"This draft can't be {verb} right now.")


# ---------------------------------------------------------------------------
# Save: idempotency claim, then saved/failed
# ---------------------------------------------------------------------------

def _stale(updated_at: str) -> bool:
    try:
        t = datetime.fromisoformat(updated_at)
    except (TypeError, ValueError):
        return True
    return datetime.now(timezone.utc) - t > timedelta(seconds=STALE_SAVING_SECONDS)


def claim_save(username: str, schema: str, draft_id, key: str, *, path=None) -> tuple[str, dict]:
    """Claim the right to call EBMS for this draft with this browser key, atomically.

    Returns (outcome, draft):
      "claimed"      status is now 'saving'; the caller must call EBMS with
                     draft["idempotency_key"] (the cycle's EBMS key, which may be an earlier
                     key when retrying a failed save) and then mark_saved / mark_failed.
      "in_progress"  another request is saving this draft right now; poll, don't call EBMS.
      "replay"       nothing to do: this key was already used for this draft, or the draft is
                     already saved. Return the current card.
    Raises DraftNotFound, IdempotencyConflict (key used for a different draft/user),
    StatusConflict (discarded), ValueError (bad key)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    key = (key or "").strip() if isinstance(key, str) else ""
    if not key or len(key) > IDEMPOTENCY_KEY_MAX or not all(c.isalnum() or c in "-_" for c in key):
        raise ValueError("Save needs a valid idempotency key.")
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        seen = conn.execute("SELECT * FROM idem_keys WHERE key = ?", (key,)).fetchone()
        if seen is not None and (seen["draft_id"] != pid or seen["username"] != u or seen["schema"] != s):
            raise IdempotencyConflict()

        def remember():
            if seen is None:
                conn.execute("INSERT INTO idem_keys (key, draft_id, cycle, username, schema, created_at)"
                             " VALUES (?, ?, ?, ?, ?, ?)", (key, pid, d["cycle"], u, s, _now()))

        status = d["status"]
        if status == "saving" and not _stale(d["updated_at"]):
            remember()
            return "in_progress", d
        if status == "saved":
            remember()
            return "replay", d
        if status == "discarded":
            raise StatusConflict(_status_message(status, "saved"), d)
        if seen is not None and status == "draft" and seen["cycle"] != d["cycle"]:
            # A key from an earlier cycle (a stale request from before an Undo or an edit that
            # rotated the EBMS key): never a second document.
            return "replay", d
        # status draft (new key, or a key of THIS cycle whose save was released by a block/503
        # check: review #7) | failed (new or same key) | stale saving
        remember()
        ebms_key = d["idempotency_key"] or key
        conn.execute(
            "UPDATE drafts SET status = 'saving', idempotency_key = ?, updated_at = ? WHERE id = ?",
            (ebms_key, _now(), pid),
        )
        return "claimed", _load(conn, u, s, pid)


def mark_saved(username: str, schema: str, draft_id, *, doc_number: str, doc_id: str | None,
               card: dict, payload: dict | None = None, before=None, after=None,
               request_id=None, response_id=None, api_user=None, path=None) -> dict:
    """saving -> saved, with the 'saved' audit row, in one transaction."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "saving":
            raise StatusConflict("This draft is no longer being saved.", d)
        now = _now()
        conn.execute(
            "UPDATE drafts SET status = 'saved', ebms_doc_number = ?, ebms_doc_id = ?, card = ?,"
            " payload = ?, saved_by = ?, saved_at = ?, review_state = 'reviewed', updated_at = ? WHERE id = ?",
            (str(doc_number), doc_id, _dumps(card), _dumps(payload if payload is not None else d["payload"]),
             u, now, now, pid),
        )
        _audit(conn, username=u, schema=s, draft_id=pid, action="saved", type_=d["type"],
               doc_number=doc_number, before=before, after=after, request_id=request_id,
               response_id=response_id, api_user=api_user)
        return _load(conn, u, s, pid)


def recover_saved(username: str, schema: str, draft_id, *, doc_number: str, doc_id: str | None,
                  card: dict | None, after=None, detail=None, api_user=None, path=None) -> dict:
    """failed or draft -> saved: an earlier, timed-out save did create the document in EBMS (found
    by the cycle's EBMS key). A draft that carries a key can be in status draft (released after a
    block, or discarded and restored). Recorded as a 'saved' audit row with a note (review #6)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] not in OPEN_STATUSES:
            raise StatusConflict("This draft is no longer waiting on a failed save.", d)
        now = _now()
        conn.execute(
            "UPDATE drafts SET status = 'saved', ebms_doc_number = ?, ebms_doc_id = ?, card = COALESCE(?, card),"
            " saved_by = ?, saved_at = ?, updated_at = ? WHERE id = ?",
            (str(doc_number), doc_id, _dumps(card), u, now, now, pid),
        )
        _audit(conn, username=u, schema=s, draft_id=pid, action="saved", type_=d["type"],
               doc_number=doc_number, before=None, after=after, detail=detail, api_user=api_user)
        return _load(conn, u, s, pid)


def mark_failed(username: str, schema: str, draft_id, *, card: dict | None, detail: str,
                before=None, request_id=None, response_id=None, api_user=None, payload: dict | None = None,
                set_detail: bool = False, path=None) -> dict:
    """saving -> failed (keeps the EBMS key so a retry finds what a timed-out call made).
    payload (optional) replaces the stored payload (e.g. new records this attempt kept).
    set_detail: also store detail on the draft (shown on the failed card and in the Review list)
    instead of only on the audit row. A part import passes it (vpa63), so its end text replaces an
    older one such as the restart text; other callers keep the default."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "saving":
            raise StatusConflict("This draft is no longer being saved.", d)
        conn.execute("UPDATE drafts SET status = 'failed', card = COALESCE(?, card), payload = COALESCE(?, payload),"
                     " updated_at = ? WHERE id = ?", (_dumps(card), _dumps(payload), _now(), pid))
        if set_detail:
            conn.execute("UPDATE drafts SET detail = ? WHERE id = ?", (detail, pid))
        _audit(conn, username=u, schema=s, draft_id=pid, action="save_failed", type_=d["type"],
               before=before, request_id=request_id, response_id=response_id, detail=detail,
               api_user=api_user)
        return _load(conn, u, s, pid)


def release_save(username: str, schema: str, draft_id, *, card: dict | None = None, path=None) -> dict:
    """saving -> draft without calling EBMS (a check turned block at save time). The cycle's
    EBMS key is kept: if an earlier attempt of this cycle timed out, the next save must still
    look that document up first; a key that was never sent is harmless (the lookup finds
    nothing and the create goes ahead)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "saving":
            return d
        conn.execute("UPDATE drafts SET status = 'draft', card = COALESCE(?, card), updated_at = ? WHERE id = ?",
                     (_dumps(card), _now(), pid))
        return _load(conn, u, s, pid)


def mark_undone(username: str, schema: str, draft_id, *, card: dict | None, before=None,
                request_id=None, response_id=None, detail=None, api_user=None, payload: dict | None = None,
                statuses: tuple[str, ...] = ("saved",), path=None) -> dict:
    """saved -> draft, with the 'undone' audit row. Clears the doc number, the cycle's EBMS key and
    the failure detail (an undone draft has no failed save to report).
    payload (optional) replaces the stored payload (e.g. records the undo removed or kept).
    statuses: the statuses it may start from. A part import's Undo also passes 'failed' and
    'draft' (an unfinished import that holds parts it changed or added, vpa63); every other
    caller keeps the default."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] not in statuses:
            raise StatusConflict("Only a saved draft can be undone.", d)
        conn.execute(
            "UPDATE drafts SET status = 'draft', ebms_doc_number = NULL, ebms_doc_id = NULL, detail = NULL,"
            " idempotency_key = NULL, cycle = cycle + 1, saved_by = NULL, saved_at = NULL, card = COALESCE(?, card),"
            " payload = COALESCE(?, payload), updated_at = ? WHERE id = ?",
            (_dumps(card), _dumps(payload), _now(), pid),
        )
        _audit(conn, username=u, schema=s, draft_id=pid, action="undone", type_=d["type"],
               doc_number=d["ebms_doc_number"], before=before, after=None,
               request_id=request_id, response_id=response_id, detail=detail, api_user=api_user)
        return _load(conn, u, s, pid)


# ---------------------------------------------------------------------------
# Uploaded documents (bills, 86e3q4zeb)
# ---------------------------------------------------------------------------

def get_document(username: str, schema: str, draft_id, *, path=None) -> dict:
    """The stored upload for this user's draft: {filename, content_type, size, sha256, pages,
    data, created_at}. DraftNotFound when the draft isn't theirs, has no document, or the
    document was purged (older than DOCUMENT_RETENTION_DAYS)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    conn = _connect(path)
    try:
        row = conn.execute(
            "SELECT filename, content_type, size, sha256, pages, data, created_at FROM documents"
            " WHERE draft_id = ? AND username = ? AND schema = ?", (pid, u, s)).fetchone()
    finally:
        conn.close()
    if row is None:
        raise DraftNotFound()
    d = dict(row)
    d["data"] = bytes(d["data"])
    return d


def retention_days(schema: str, *, path=None) -> int:
    """How long this dataset keeps uploads (company setting, default DOCUMENT_RETENTION_DAYS;
    never more than DOCUMENT_RETENTION_DAYS, so an old stored 60 or 90 now means 30)."""
    try:
        return min(int(get_company_settings(schema, path=path)["document_retention_days"]),
                   DOCUMENT_RETENTION_DAYS)
    except (ValueError, KeyError):
        return DOCUMENT_RETENTION_DAYS


def _purge_documents(days, path, fixed_days: bool = False):
    """Returns (count, bytes) of the uploads deleted."""
    def cutoff(d):
        return (datetime.now(timezone.utc) - timedelta(days=d)).isoformat(timespec="microseconds")
    if days is not None:
        with _Tx(path) as conn:
            size = conn.execute("SELECT COALESCE(SUM(size), 0) FROM documents WHERE created_at < ?",
                                (cutoff(days),)).fetchone()[0]
            return conn.execute("DELETE FROM documents WHERE created_at < ?", (cutoff(days),)).rowcount, size
    conn = _connect(path)
    try:
        schemas = [r["schema"] for r in conn.execute("SELECT DISTINCT schema FROM documents").fetchall()]
    finally:
        conn.close()
    gone = size = 0
    for sch in schemas:
        keep = DOCUMENT_RETENTION_DAYS if fixed_days else retention_days(sch, path=path)
        with _Tx(path) as conn:
            size += conn.execute("SELECT COALESCE(SUM(size), 0) FROM documents WHERE schema = ? AND created_at < ?",
                                 (sch, cutoff(keep))).fetchone()[0]
            gone += conn.execute("DELETE FROM documents WHERE schema = ? AND created_at < ?",
                                 (sch, cutoff(keep))).rowcount
    return gone, size


def purge_documents(*, days: int | None = None, path=None) -> int:
    """Delete uploads older than `days` (any user), or, when days is None, older than each
    dataset's own retention setting (capped at DOCUMENT_RETENTION_DAYS). Returns how many went.
    Audit is untouched."""
    return _purge_documents(days, path)[0]


def purge_drafts(*, days: int = DRAFT_RETENTION_DAYS, path=None, _keep_with_documents: bool = False) -> int:
    """Delete drafts not touched for `days` days, with their documents and idempotency keys.
    Skips drafts mid-save or mid-read. Audit is untouched. Returns the drafts deleted.
    (_keep_with_documents: purge_all while the uploads table is held back by its cap.)"""
    cutoff = (datetime.now(timezone.utc) - timedelta(days=int(days))).isoformat(timespec="microseconds")
    with _Tx(path) as conn:
        ids = [r[0] for r in conn.execute(
            "SELECT id FROM drafts WHERE updated_at < ? AND status NOT IN ('saving', 'reading')"
            + (" AND id NOT IN (SELECT draft_id FROM documents)" if _keep_with_documents else ""),
            (cutoff,)).fetchall()]
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            marks = ",".join("?" * len(chunk))
            conn.execute(f"DELETE FROM idem_keys WHERE draft_id IN ({marks})", chunk)
            conn.execute(f"DELETE FROM documents WHERE draft_id IN ({marks})", chunk)
            conn.execute(f"DELETE FROM drafts WHERE id IN ({marks})", chunk)
        return len(ids)


def _iso_ago(days, ref: str | None = None) -> str:
    base = datetime.fromisoformat(ref) if ref else datetime.now(timezone.utc)
    return (base - timedelta(days=days)).isoformat(timespec="microseconds")


def _purge_plan(conn, path, last) -> dict:
    """Per table: total rows, `due` (past the cutoff right now) and `backlog` (the part that was
    already overdue at the previous run `last`; on a first run, all of it). Count queries only. The
    documents count uses DOCUMENT_RETENTION_DAYS, not a company setting: a lowered setting (7 days)
    makes uploads of 8 to 30 days routine daily work, not something for the cap to hold."""
    ok = "status NOT IN ('saving', 'reading')"
    due_d = f"SELECT id FROM drafts WHERE updated_at < ? AND {ok}"
    out = {}
    for label, ref in (("due", None), ("backlog", last)):
        cut_d = _iso_ago(DRAFT_RETENTION_DAYS, ref)
        n_drafts = conn.execute(f"SELECT COUNT(*) FROM ({due_d})", (cut_d,)).fetchone()[0]
        n_docs = conn.execute(
            f"SELECT COUNT(*) FROM documents WHERE created_at < ? OR draft_id IN ({due_d})",
            (_iso_ago(DOCUMENT_RETENTION_DAYS, ref), cut_d)).fetchone()[0]
        n_audit = conn.execute("SELECT COUNT(*) FROM audit WHERE at < ?",
                               (_iso_ago(AUDIT_RETENTION_DAYS, ref),)).fetchone()[0]
        for name, n in (("drafts", n_drafts), ("documents", n_docs), ("audit", n_audit)):
            out.setdefault(name, {})[label] = n
    for name in out:
        out[name]["total"] = conn.execute(f"SELECT COUNT(*) FROM {name}").fetchone()[0]
    return out


def _newest_stamp(conn) -> str:
    return max((conn.execute(f"SELECT MAX({col}) FROM {tbl}").fetchone()[0] or ""
                for tbl, col in (("drafts", "updated_at"), ("audit", "at"), ("documents", "created_at"))))


def _last_purge_at(conn) -> str | None:
    conn.execute(_PURGE_STATE_DDL)     # a v6 file made before purge_state existed
    row = conn.execute("SELECT last_purge_at FROM purge_state WHERE id = 1").fetchone()
    return row[0] if row else None


def _write_last_purge(path) -> None:
    with _Tx(path) as conn:
        conn.execute(_PURGE_STATE_DDL)
        conn.execute("INSERT OR REPLACE INTO purge_state (id, last_purge_at) VALUES (1, ?)", (_now(),))


def _remove_leftover_copies(path) -> None:
    p = db_path(path)
    for name in (".pre-v6", ".pre-v6.tmp"):
        base = p.with_name(p.name + name)
        if any(base.with_name(base.name + suf).exists() for suf in ("", "-wal", "-shm", "-journal")):
            _wipe_files(base)


def purge_all(*, path=None, force: bool = False) -> dict:
    """Run the document, draft and audit purges, then truncate the WAL (and VACUUM when over a
    quarter of the pages are free). All steps are attempted even if one fails; the first failure is
    re-raised afterwards. A hygiene problem (VACUUM or checkpoint) does not raise: the counts are
    returned with "hygiene_error": True so the caller can log them. Logs nothing.

    Guards (the purge must never delete more than the rules say, whatever the clock does):
      "skipped": "clock"  the clock looks wrong: a stored timestamp more than a day in the future,
                          or the last recorded purge later than now. Nothing was deleted.
      "capped": [tables]  a table is held back (left untouched) when it has 20 rows or more and more
                          than half of it is due. "Due" is judged on the rows that were already
                          overdue at the previous run when that run was 2 days ago or less (rows that
                          just became due are daily work), and on everything past its cutoff when
                          the gap is longer or there was no previous run: a clock jump or an install
                          that was off can then never delete more than half of a table. On a file's
                          first run the whole run is held back ("capped" plus "held": "first_run",
                          nothing deleted, nothing recorded) when a big table would lose over half AND
                          the newest stored timestamp is over 30 days old (a clock jump and a quiet
                          install look the same). While uploads are held back (or their step failed)
                          drafts that still have an upload are kept: no orphan upload, no reused id.
    Uploads are removed by the 30-day rule alone on a run whose gap since last_purge_at is over 2
    days (or that has no last_purge_at): a lowered company setting (7 or 14 days) applies only on
    normal runs, so after an outage or a clock jump it waits for the next normal run.
    last_purge_at is written after every run that passed the clock guard without a failed step,
    except a run held back after a gap of over 2 days (it could record a stamp from a wrong clock). force=True lifts every guard: the operator is declaring
    the clock fine (check it first)."""
    result = {"documents": 0, "drafts": 0, "audit": 0}
    if not db_path(path).exists():
        return result
    conn = _connect(path)
    try:
        if _integrity_ok(conn):
            _remove_leftover_copies(path)    # a crash must never leave a full-data copy lying around
        else:
            log.error("Assist drafts file failed its integrity check; any copy from before the upgrade was kept")
        last = _last_purge_at(conn)
        now = datetime.now(timezone.utc)
        if not force:
            if _newest_stamp(conn) > (now + timedelta(days=PURGE_CLOCK_FUTURE_DAYS)).isoformat(timespec="microseconds") \
                    or (last is not None and last > now.isoformat(timespec="microseconds")):
                result["skipped"] = "clock"
                return result
        plan = _purge_plan(conn, path, last)
        # A normal daily run (gap of 2 days or less) is judged on the backlog that was already overdue
        # at the previous run; a longer gap (an install that was off, or a clock jump) on everything due.
        jumped = last is not None and last < _iso_ago(PURGE_JUMP_DAYS)
        measure = "due" if (jumped or last is None) else "backlog"
        big = [n for n in ("documents", "drafts", "audit")
               if plan[n]["total"] >= PURGE_CAP_MIN_ROWS
               and plan[n][measure] > PURGE_CAP_FRACTION * plan[n]["total"]]
        quiet = _newest_stamp(conn) < _iso_ago(PURGE_GAP_DAYS)
    finally:
        conn.close()
    if last is None and big and quiet and not force:
        result["capped"] = big        # first run on a file whose data is old: an operator confirms with force
        result["held"] = "first_run"
        return result
    capped = [] if (force or last is None) else list(big)   # a first run is not capped (held above if quiet)
    first = None
    doc_bytes = 0
    docs_failed = False
    for name in ("documents", "drafts", "audit"):
        if name in capped:
            continue                  # held back
        try:
            if name == "documents":
                result[name], doc_bytes = _purge_documents(None, path, fixed_days=jumped or last is None)
            elif name == "drafts":
                # drafts that still have an upload stay while the uploads are held back (or failed):
                # no orphan upload, no reused draft id
                result[name] = purge_drafts(path=path, _keep_with_documents="documents" in capped or docs_failed)
            else:
                result[name] = purge_audit(path=path)
        except Exception as exc:
            if name == "documents":
                docs_failed = True
            if first is None:
                first = exc
    if capped:
        result["capped"] = [n for n in ("documents", "drafts", "audit") if n in capped]
    hygiene_failed = False
    conn = None
    try:
        conn = _connect(path)
    except Exception:
        hygiene_failed = True
    if conn is not None:
        try:
            # VACUUM is only space reclaim (secure_delete already zeroed freed pages). It holds
            # the write lock, so run it only when a quarter of the file is free pages.
            try:
                pages = conn.execute("PRAGMA page_count").fetchone()[0]
                free = conn.execute("PRAGMA freelist_count").fetchone()[0]
                if pages and free / pages > 0.25:
                    conn.execute("VACUUM")
            except Exception:
                hygiene_failed = True
            # Own try: a failed VACUUM must not skip the checkpoint that zeroes the WAL.
            try:
                row = conn.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
                if row is not None and row[0] != 0:
                    hygiene_failed = True  # busy: deleted bytes may still sit in the WAL
            except Exception:
                hygiene_failed = True
        finally:
            conn.close()
    if hygiene_failed:
        result["hygiene_error"] = True
    if first is not None:
        raise first
    try:
        if not (jumped and capped):      # a held run after a big gap must not record a (future) stamp
            _write_last_purge(path)
    except Exception:
        result["hygiene_error"] = True   # not recorded: the next run still counts as a first run
    return result


# ---------------------------------------------------------------------------
# Audit
# ---------------------------------------------------------------------------

def record_audit(username: str, schema: str, draft_id, action: str, type_: str | None, *,
                 doc_number=None, before=None, after=None, request_id=None, response_id=None,
                 detail=None, api_user=None, path=None) -> int:
    """Append one audit row on its own (e.g. undo_failed). Returns its id."""
    u, s = _owner(username, schema)
    with _Tx(path) as conn:
        return _audit(conn, username=u, schema=s, draft_id=draft_id, action=action, type_=type_,
                      doc_number=doc_number, before=before, after=after, request_id=request_id,
                      response_id=response_id, detail=detail, api_user=api_user)


def list_audit(schema: str, *, actions=None, types=None, limit: int = 200, path=None) -> list[dict]:
    """Audit rows for this dataset (every user), newest first. before/after decoded."""
    s = _norm_schema(schema)
    if not s:
        raise ValueError("A dataset is required.")
    where, args = ["schema = ?"], [s]
    if actions:
        where.append(f"action IN ({','.join('?' for _ in actions)})")
        args.extend(actions)
    if types:
        where.append(f"type IN ({','.join('?' for _ in types)})")
        args.extend(types)
    conn = _connect(path)
    try:
        rows = conn.execute(
            f"SELECT * FROM audit WHERE {' AND '.join(where)} ORDER BY id DESC LIMIT ?",
            (*args, max(1, min(int(limit), 1000))),
        ).fetchall()
    finally:
        conn.close()
    out = []
    for r in rows:
        d = dict(r)
        d["before"] = json.loads(d["before"]) if d.get("before") else None
        d["after"] = json.loads(d["after"]) if d.get("after") else None
        out.append(d)
    return out


def import_journal_newest(username: str, schema: str, draft_id, *, path=None) -> dict[str, dict]:
    """The newest journal row per part in the draft's current cycle (after its newest 'undone' or
    'created' row: IMPORT_CYCLE_START),
    keyed by after["part"] (rows with a blank or missing part are skipped): part_update_sent /
    part_create_sent (sent by a Save, outcome not known yet), part_undo_sent (an Undo's restore or
    removal was about to be sent; outcome not known yet; after["entry"] is the entry it undid) or
    part_settled (closed; after["outcome"]). Ordered by row id, never by time, so rows written out of
    order by concurrent workers still pair up per part. One read serves Save's start merge and an
    Undo's state. Value: {"id", "action", "before", "after"}, decoded."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    actions = IMPORT_JOURNAL_ACTIONS + (IMPORT_SETTLED_ACTION, IMPORT_UNDO_SENT_ACTION)
    marks = ",".join("?" for _ in actions)
    conn = _connect(path)
    try:
        rows = conn.execute(
            f"SELECT id, action, before, after FROM audit WHERE username = ? AND schema = ?"
            f" AND draft_id = ? AND action IN ({marks}) AND id > COALESCE((SELECT MAX(id) FROM audit"
            f" WHERE username = ? AND schema = ? AND draft_id = ? AND action IN {IMPORT_CYCLE_START}), 0)"
            f" ORDER BY id",
            (u, s, pid, *actions, u, s, pid),
        ).fetchall()
    finally:
        conn.close()
    out: dict[str, dict] = {}
    for r in rows:   # oldest first, so the newest row per part wins
        after = json.loads(r["after"]) if r["after"] else None
        part = after.get("part") if isinstance(after, dict) else None
        if not isinstance(part, str) or not part.strip():
            continue
        out[part] = {"id": r["id"], "action": r["action"],
                     "before": json.loads(r["before"]) if r["before"] else None, "after": after}
    return out


def import_writes_sent(username: str, schema: str, draft_id, *, path=None) -> dict[str, dict]:
    """The part import's write-ahead journal for this user's draft (vpa63, spec D3): the parts sent
    to EBMS whose outcome is not settled yet.

    A part is returned when its newest row in the cycle (see import_journal_newest) is a Save's sent
    row (part_update_sent / part_create_sent); a part whose newest row is a part_settled closing row
    (a re-check read it as not written or gone, or an Undo settled it) or an Undo's part_undo_sent
    row is left out, until a newer sent row (sent again) opens it again. A part a re-check found
    done is NOT closed: its done entry carries it. Value: {"id", "action", "before", "after"} of
    that sent row, before/after decoded."""
    return {p: r for p, r in import_journal_newest(username, schema, draft_id, path=path).items()
            if r["action"] in IMPORT_JOURNAL_ACTIONS}


def import_undo_started(username: str, schema: str, draft_id, *, path=None) -> bool:
    """vpa63 (round 4, owner ruling Nov 20): has an Undo started on this import in its current cycle
    (after its newest 'undone' or 'created' row)? True when ANY row of the cycle is an Undo's part_undo_sent row or
    a part_settled row with an Undo outcome (IMPORT_UNDO_OUTCOMES), whatever row came after it for
    that part. While it is true the server refuses Save on the import: only Undo (whose full finish
    writes 'undone' and so starts a new cycle) or Discard goes on from there. Raises whatever the
    read raises; callers treat that as "can't tell" and refuse (fail closed)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    conn = _connect(path)
    try:
        rows = conn.execute(
            "SELECT action, after FROM audit WHERE username = ? AND schema = ? AND draft_id = ?"
            " AND action IN (?, ?) AND id > COALESCE((SELECT MAX(id) FROM audit"
            f" WHERE username = ? AND schema = ? AND draft_id = ? AND action IN {IMPORT_CYCLE_START}), 0)",
            (u, s, pid, IMPORT_UNDO_SENT_ACTION, IMPORT_SETTLED_ACTION, u, s, pid),
        ).fetchall()
    finally:
        conn.close()
    for r in rows:
        if r["action"] == IMPORT_UNDO_SENT_ACTION:
            return True
        after = json.loads(r["after"]) if r["after"] else None
        if isinstance(after, dict) and after.get("outcome") in IMPORT_UNDO_OUTCOMES:
            return True
    return False


# ---------------------------------------------------------------------------
# Settings. Per user and dataset (Settings > Data entry / Display) and per dataset for the
# whole company (Settings > Company, EBMS Administrators only; every change is audited).
# A value is on/off (default bool) or one of a fixed list (default str, CHOICES). server.py
# owns the labels and which server switches may still force a feature off.
# ---------------------------------------------------------------------------

USER_SETTINGS = {
    "bill_po_match": True,     # offer to save a bill on the open PO it matches (research K.6)
    "new_records": True,       # offer to create a missing customer, vendor or part
    "auto_refresh": "15",      # dashboard refresh, minutes ("off" = never)
    "theme": "dark",
    "hide_sql": False,
}
COMPANY_SETTINGS = {
    "bill_writes": True,
    "so_writes": True,
    "new_party_records": True,     # new customers and vendors (parts are always allowed)
    "bill_po_match": True,
    "old_invoice_days": "90",
    "document_retention_days": "30",
}
CHOICES = {
    "auto_refresh": ("off", "5", "15", "30"),
    "theme": ("dark", "light"),
    "old_invoice_days": ("30", "60", "90", "180", "365"),
    "document_retention_days": ("7", "14", "30"),
}


def _encode(defaults: dict, key: str, value) -> str:
    if key not in defaults:
        raise ValueError("Unknown setting.")
    if isinstance(defaults[key], bool):
        if not isinstance(value, bool):
            raise ValueError("That setting is on or off.")
        return "1" if value else "0"
    v = str(value).strip().lower() if isinstance(value, (str, int)) and not isinstance(value, bool) else None
    if v not in CHOICES[key]:
        raise ValueError("Pick one of: " + ", ".join(CHOICES[key]) + ".")
    return v


def _decoded(defaults: dict, rows) -> dict:
    out = dict(defaults)
    for r in rows:
        k, v = r["key"], r["value"]
        if k not in defaults:
            continue
        if isinstance(defaults[k], bool):
            out[k] = v == "1"
        elif v in CHOICES[k]:
            out[k] = v
    return out


def get_settings(username: str, schema: str, *, path=None) -> dict:
    """{key: value} for every user setting: the stored choice, else the default."""
    u, s = _owner(username, schema)
    conn = _connect(path)
    try:
        rows = conn.execute("SELECT key, value FROM user_settings WHERE username = ? AND schema = ?",
                            (u, s)).fetchall()
    finally:
        conn.close()
    return _decoded(USER_SETTINGS, rows)


def saved_setting_keys(username: str, schema: str, *, path=None) -> list[str]:
    """The user settings this user has actually chosen (the rest are defaults)."""
    u, s = _owner(username, schema)
    conn = _connect(path)
    try:
        return sorted(r["key"] for r in conn.execute(
            "SELECT key FROM user_settings WHERE username = ? AND schema = ?", (u, s)).fetchall())
    finally:
        conn.close()


def set_setting(username: str, schema: str, key: str, value, *, path=None) -> dict:
    """Save one user setting and return them all. ValueError (safe to show) on a bad key/value."""
    u, s = _owner(username, schema)
    enc = _encode(USER_SETTINGS, key, value)
    conn = _connect(path)
    try:
        conn.execute(
            "INSERT INTO user_settings (username, schema, key, value, updated_at) VALUES (?, ?, ?, ?, ?)"
            " ON CONFLICT(username, schema, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
            (u, s, key, enc, _now()))
    finally:
        conn.close()
    return get_settings(username, schema, path=path)


def get_company_settings(schema: str, *, path=None) -> dict:
    s = _norm_schema(schema)
    if not s:
        return dict(COMPANY_SETTINGS)
    conn = _connect(path)
    try:
        rows = conn.execute("SELECT key, value FROM company_settings WHERE schema = ?", (s,)).fetchall()
    finally:
        conn.close()
    return _decoded(COMPANY_SETTINGS, rows)


def set_company_setting(username: str, schema: str, key: str, value, *, path=None) -> dict:
    """Save one company setting and append a 'setting_changed' audit row in the same
    transaction (before/after = {key: value}). Returns all company settings."""
    u, s = _owner(username, schema)
    enc = _encode(COMPANY_SETTINGS, key, value)
    before = get_company_settings(s, path=path)[key]
    with _Tx(path) as conn:
        conn.execute(
            "INSERT INTO company_settings (schema, key, value, updated_at, updated_by) VALUES (?, ?, ?, ?, ?)"
            " ON CONFLICT(schema, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at,"
            " updated_by = excluded.updated_by",
            (s, key, enc, _now(), u))
        after = _decoded(COMPANY_SETTINGS, [{"key": key, "value": enc}])[key]
        _audit(conn, username=u, schema=s, draft_id=None, action="setting_changed", type_="setting",
               before={key: before}, after={key: after})
    return get_company_settings(s, path=path)
